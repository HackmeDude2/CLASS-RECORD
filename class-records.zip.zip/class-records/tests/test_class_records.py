"""Comprehensive unittest suite for CLASS RECORDS Python college project."""

from __future__ import annotations

import os
import tempfile
import unittest

from app import create_app
from backend.calculations import (
    calculate_student_attendance,
    calculate_student_fees,
    calculate_teacher_payroll,
)


class CalculationTests(unittest.TestCase):
    def test_student_0_of_1_then_1_of_2_fifty_percent(self):
        # Class 1: student was absent -> 0/1 (0.0%)
        first_class = calculate_student_attendance([{"status": "absent"}], "0.5")
        self.assertEqual(first_class["presentCount"], 0)
        self.assertEqual(first_class["absentCount"], 1)
        self.assertEqual(first_class["ratio"], "0/1")
        self.assertEqual(first_class["percentage"], 0.0)

        # Class 2: student was present -> 1/2 (50.0%)
        second_class = calculate_student_attendance(
            [{"status": "absent"}, {"status": "present"}], "0.5"
        )
        self.assertEqual(second_class["presentCount"], 1)
        self.assertEqual(second_class["absentCount"], 1)
        self.assertEqual(second_class["ratio"], "1/2")
        self.assertEqual(second_class["percentage"], 50.0)

    def test_leave_has_less_percentage_minus_than_absent(self):
        with_absent = calculate_student_attendance(
            [{"status": "present"}, {"status": "absent"}], "0.5"
        )
        with_leave = calculate_student_attendance(
            [{"status": "present"}, {"status": "leave"}], "0.5"
        )
        # 1 Present + 1 Absent = 50%, whereas 1 Present + 1 Leave = 75% (less minus!)
        self.assertEqual(with_absent["percentage"], 50.0)
        self.assertEqual(with_leave["percentage"], 75.0)
        self.assertGreater(with_leave["percentage"], with_absent["percentage"])

    def test_teacher_deduction_only_above_4_holidays(self):
        teacher = {
            "monthlySalary": 30000,
            "freeHolidaysAllowed": 4,
            "deductionMode": "pro_rata",
            "fixedDeductionPerDay": 1000,
        }
        # Exactly 4 holidays in Nov (30 days) -> 0 deduction
        four_holidays = [{"status": "holiday"} for _ in range(4)]
        p4 = calculate_teacher_payroll(teacher, "2026-11", four_holidays)
        self.assertEqual(p4["excessHolidays"], 0)
        self.assertEqual(p4["deductionAmount"], 0)
        self.assertEqual(p4["netSalary"], 30000)

        # 6 holidays -> 2 extra days * 1000/day = 2000 deduction
        six_holidays = [{"status": "holiday"} for _ in range(6)]
        p6 = calculate_teacher_payroll(teacher, "2026-11", six_holidays)
        self.assertEqual(p6["holidaysTaken"], 6)
        self.assertEqual(p6["excessHolidays"], 2)
        self.assertEqual(p6["perDayDeduction"], 1000)
        self.assertEqual(p6["deductionAmount"], 2000)
        self.assertEqual(p6["netSalary"], 28000)

    def test_student_fees_left_calculation(self):
        s_partial = {"totalFees": 45000, "feesPaid": 20000, "feeDueDate": "2026-11-15"}
        res = calculate_student_fees(s_partial, "2026-11-26")
        self.assertEqual(res["feesLeft"], 25000)
        self.assertEqual(res["status"], "partial")
        self.assertTrue(res["isOverdue"])


class ApiAndRbacTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        self.tmp.close()
        self.app = create_app(self.tmp.name)
        self.client = self.app.test_client()

    def tearDown(self):
        for suffix in ("", "-wal", "-shm"):
            p = f"{self.tmp.name}{suffix}"
            if os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass

    def test_admin_only_subject_creation_and_teacher_only_attendance(self):
        # Teacher CANNOT add subject classes -> 403
        res_teacher_sub = self.client.post(
            "/api/subjects",
            headers={"x-role": "teacher"},
            json={"code": "AI-401", "name": "Artificial Intelligence", "classGrade": "B.Tech CS • Sem 3"},
        )
        self.assertEqual(res_teacher_sub.status_code, 403)

        # Admin CAN add subject classes -> 201
        res_admin_sub = self.client.post(
            "/api/subjects",
            headers={"x-role": "admin"},
            json={
                "code": "AI-401",
                "name": "Artificial Intelligence",
                "classGrade": "B.Tech CS • Sem 3",
                "teacherId": "tch_meera",
            },
        )
        self.assertEqual(res_admin_sub.status_code, 201)
        sub_id = res_admin_sub.get_json()["subject"]["id"]

        # Admin CANNOT mark student attendance -> 403
        res_admin_ses = self.client.post(
            "/api/sessions",
            headers={"x-role": "admin"},
            json={"subjectId": sub_id, "sessionDate": "2026-11-26"},
        )
        self.assertEqual(res_admin_ses.status_code, 403)

        # Teacher CAN take Class 1 (stu_01 absent -> 0/1 = 0%) and Class 2 (stu_01 present -> 1/2 = 50%)
        ses1 = self.client.post(
            "/api/sessions",
            headers={"x-role": "teacher"},
            json={
                "subjectId": sub_id,
                "sessionDate": "2026-11-26",
                "topic": "Lecture 1",
                "records": [{"studentId": "stu_01", "status": "absent"}],
            },
        )
        self.assertEqual(ses1.status_code, 201)

        boot1 = self.client.get("/api/bootstrap?month=2026-11").get_json()
        st1 = boot1["studentSummaries"]["stu_01"]["bySubject"][sub_id]
        self.assertEqual(st1["ratio"], "0/1")
        self.assertEqual(st1["percentage"], 0.0)

        ses2 = self.client.post(
            "/api/sessions",
            headers={"x-role": "teacher"},
            json={
                "subjectId": sub_id,
                "sessionDate": "2026-11-26",
                "topic": "Lecture 2",
                "records": [{"studentId": "stu_01", "status": "present"}],
            },
        )
        self.assertEqual(ses2.status_code, 201)

        boot2 = self.client.get("/api/bootstrap?month=2026-11").get_json()
        st2 = boot2["studentSummaries"]["stu_01"]["bySubject"][sub_id]
        self.assertEqual(st2["ratio"], "1/2")
        self.assertEqual(st2["percentage"], 50.0)

    def test_teacher_holiday_update_fees_payment_and_csv_exports(self):
        # Teacher cannot mark teacher holidays (Admin only)
        r_forbid = self.client.put(
            "/api/teacher-attendance",
            headers={"x-role": "teacher"},
            json={"teacherId": "tch_meera", "date": "2026-11-26", "status": "holiday"},
        )
        self.assertEqual(r_forbid.status_code, 403)

        # Admin marks 2 more holidays for Prof. Meera (had 3 -> now 5 > 4 -> 1 extra day)
        for dt in ("2026-11-26", "2026-11-27"):
            r_ok = self.client.put(
                "/api/teacher-attendance",
                headers={"x-role": "admin"},
                json={"teacherId": "tch_meera", "date": dt, "status": "holiday"},
            )
            self.assertEqual(r_ok.status_code, 200)

        boot = self.client.get("/api/bootstrap?month=2026-11").get_json()
        meera_pay = boot["teacherPayrolls"]["tch_meera"]
        self.assertEqual(meera_pay["holidaysTaken"], 5.0)
        self.assertEqual(meera_pay["excessHolidays"], 1.0)
        self.assertEqual(meera_pay["deductionAmount"], 1600.0)
        self.assertEqual(meera_pay["netSalary"], 46400.0)

        # Teacher cannot collect student fees -> 403; Admin collects -> reduces feesLeft
        r_fee_forbid = self.client.post(
            "/api/students/stu_02/payments",
            headers={"x-role": "teacher"},
            json={"amount": 5000},
        )
        self.assertEqual(r_fee_forbid.status_code, 403)

        r_fee_ok = self.client.post(
            "/api/students/stu_02/payments",
            headers={"x-role": "admin"},
            json={"amount": 5000, "method": "UPI"},
        )
        self.assertEqual(r_fee_ok.status_code, 201)
        boot_after = self.client.get("/api/bootstrap?month=2026-11").get_json()
        self.assertEqual(boot_after["studentSummaries"]["stu_02"]["fees"]["feesLeft"], 15000.0)

        # CSV export endpoints succeed
        csv_att = self.client.get("/api/export/student-attendance.csv?month=2026-11")
        csv_pay = self.client.get("/api/export/teacher-payroll.csv?month=2026-11")
        self.assertEqual(csv_att.status_code, 200)
        self.assertEqual(csv_pay.status_code, 200)
        self.assertIn(b"26CS01", csv_att.data)
        self.assertIn(b"FAC-101", csv_pay.data)


if __name__ == "__main__":
    unittest.main()

"""Main Flask application for CLASS RECORDS.

App Name: CLASS RECORDS
Company: THE SHIVAGROUPS OF APP
Developed By: RUDRAKSH GARG
"""

from __future__ import annotations

import csv
import io
import os
from datetime import UTC, date, datetime

from flask import Flask, Response, jsonify, request, send_from_directory

from backend.database import (
    DEFAULT_DB_PATH,
    build_bootstrap_payload,
    create_id,
    get_connection,
    get_settings_map,
    init_db,
)


def create_app(db_path: str = DEFAULT_DB_PATH) -> Flask:
    static_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
    app = Flask(__name__, static_folder=static_folder, static_url_path="")
    app.config["DB_PATH"] = db_path
    init_db(db_path, seed=True)

    def get_role() -> str:
        role = str(request.headers.get("x-role", "student")).lower().strip()
        return role if role in ("admin", "teacher", "student") else "student"

    def db_conn():
        return get_connection(app.config["DB_PATH"])

    @app.route("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.route("/api/health", methods=["GET"])
    def health():
        return jsonify(
            {
                "ok": True,
                "app": "CLASS RECORDS",
                "company": "THE SHIVAGROUPS OF APP",
                "developer": "RUDRAKSH GARG",
            }
        )

    @app.route("/api/bootstrap", methods=["GET"])
    def bootstrap():
        month = request.args.get("month", "2026-11")
        conn = db_conn()
        try:
            return jsonify(build_bootstrap_payload(conn, month))
        finally:
            conn.close()

    @app.route("/api/auth/verify", methods=["POST"])
    def verify_auth():
        body = request.get_json(silent=True) or {}
        target_role = str(body.get("role", "")).lower().strip()
        pin = str(body.get("pin", ""))

        conn = db_conn()
        try:
            settings = get_settings_map(conn)
            if target_role == "admin":
                if pin == str(settings.get("adminPin", "1234")):
                    return jsonify({"verified": True, "role": "admin"})
                return jsonify({"verified": False, "error": "Invalid Admin Passcode."}), 401

            if target_role == "teacher":
                teacher_id = body.get("teacherId")
                if teacher_id:
                    teacher = conn.execute(
                        "SELECT id, name, pin FROM teachers WHERE id = ?",
                        (teacher_id,),
                    ).fetchone()
                    if not teacher:
                        return jsonify({"verified": False, "error": "Teacher not found."}), 404
                    expected = str(teacher["pin"] or settings.get("teacherDefaultPin", "1111"))
                    if pin == expected:
                        return jsonify(
                            {"verified": True, "role": "teacher", "teacherId": teacher["id"]}
                        )
                    return jsonify({"verified": False, "error": "Invalid Teacher Passcode."}), 401
                if pin == str(settings.get("teacherDefaultPin", "1111")):
                    return jsonify({"verified": True, "role": "teacher"})
                return jsonify({"verified": False, "error": "Invalid Teacher Passcode."}), 401

            return jsonify({"verified": True, "role": "student"})
        finally:
            conn.close()

    # ==================== ADMIN-ONLY ENDPOINTS ====================
    @app.route("/api/settings", methods=["PUT"])
    def update_settings():
        if get_role() != "admin":
            return jsonify({"error": "Only Admin Panel can update institutional settings."}), 403
        body = request.get_json(silent=True) or {}
        allowed = [
            "institutionName",
            "departmentBanner",
            "currency",
            "freeHolidaysLimit",
            "leaveCreditWeight",
            "minAttendanceTarget",
            "adminPin",
            "teacherDefaultPin",
        ]
        conn = db_conn()
        try:
            for key in allowed:
                if key in body and body[key] is not None:
                    conn.execute(
                        "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                        (key, str(body[key])),
                    )
            conn.commit()
            return jsonify({"ok": True, "settings": get_settings_map(conn)})
        finally:
            conn.close()

    @app.route("/api/subjects", methods=["POST"])
    def create_subject():
        if get_role() != "admin":
            return (
                jsonify(
                    {"error": "Subject & Class creation is restricted to Admin Panel only."}
                ),
                403,
            )
        body = request.get_json(silent=True) or {}
        name = str(body.get("name", "")).strip()
        code = str(body.get("code", "")).strip().upper()
        class_grade = str(body.get("classGrade", "B.Tech CS • Sem 3")).strip()
        if not name or not code:
            return jsonify({"error": "Subject name and code are required."}), 400

        sid = create_id("sub")
        now = datetime.now(UTC).isoformat()
        conn = db_conn()
        try:
            conn.execute(
                """
                INSERT INTO subjects (
                    id, code, name, classGrade, teacherId, scheduleNote, accentColor, createdAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    sid,
                    code,
                    name,
                    class_grade,
                    body.get("teacherId") or None,
                    str(body.get("scheduleNote", "")),
                    str(body.get("accentColor", "#D4AF37")),
                    now,
                ),
            )
            student_ids = body.get("studentIds")
            if not isinstance(student_ids, list):
                student_ids = [
                    r["id"]
                    for r in conn.execute(
                        "SELECT id FROM students WHERE classGrade = ?",
                        (class_grade,),
                    ).fetchall()
                ]
                if not student_ids:
                    student_ids = [
                        r["id"] for r in conn.execute("SELECT id FROM students").fetchall()
                    ]
            for st_id in student_ids:
                conn.execute(
                    "INSERT OR IGNORE INTO student_subjects (studentId, subjectId) VALUES (?, ?)",
                    (st_id, sid),
                )
            conn.commit()
            created = dict(
                conn.execute("SELECT * FROM subjects WHERE id = ?", (sid,)).fetchone()
            )
            return jsonify({"subject": created}), 201
        finally:
            conn.close()

    @app.route("/api/subjects/<subject_id>", methods=["PUT", "DELETE"])
    def manage_subject(subject_id: str):
        if get_role() != "admin":
            return (
                jsonify(
                    {"error": "Subject & Class modifications are restricted to Admin Panel only."}
                ),
                403,
            )
        conn = db_conn()
        try:
            existing = conn.execute("SELECT * FROM subjects WHERE id = ?", (subject_id,)).fetchone()
            if not existing:
                return jsonify({"error": "Subject class not found."}), 404

            if request.method == "DELETE":
                conn.execute("DELETE FROM subjects WHERE id = ?", (subject_id,))
                conn.commit()
                return jsonify({"ok": True})

            body = request.get_json(silent=True) or {}
            conn.execute(
                """
                UPDATE subjects
                SET code = ?, name = ?, classGrade = ?, teacherId = ?, scheduleNote = ?, accentColor = ?
                WHERE id = ?
                """,
                (
                    str(body.get("code", existing["code"])).strip().upper(),
                    str(body.get("name", existing["name"])).strip(),
                    str(body.get("classGrade", existing["classGrade"])).strip(),
                    body.get("teacherId") if "teacherId" in body else existing["teacherId"],
                    str(body.get("scheduleNote", existing["scheduleNote"])),
                    str(body.get("accentColor", existing["accentColor"])),
                    subject_id,
                ),
            )
            if isinstance(body.get("studentIds"), list):
                conn.execute("DELETE FROM student_subjects WHERE subjectId = ?", (subject_id,))
                for st_id in body["studentIds"]:
                    conn.execute(
                        "INSERT OR IGNORE INTO student_subjects (studentId, subjectId) VALUES (?, ?)",
                        (st_id, subject_id),
                    )
            conn.commit()
            updated = dict(
                conn.execute("SELECT * FROM subjects WHERE id = ?", (subject_id,)).fetchone()
            )
            return jsonify({"subject": updated})
        finally:
            conn.close()

    @app.route("/api/teachers", methods=["POST"])
    def create_teacher():
        if get_role() != "admin":
            return jsonify({"error": "Only Admin Panel can add faculty records."}), 403
        body = request.get_json(silent=True) or {}
        name = str(body.get("name", "")).strip()
        employee_id = str(body.get("employeeId", "")).strip().upper()
        if not name or not employee_id:
            return jsonify({"error": "Teacher name and Faculty ID are required."}), 400

        tid = create_id("tch")
        now = datetime.now(UTC).isoformat()
        conn = db_conn()
        try:
            conn.execute(
                """
                INSERT INTO teachers (
                    id, employeeId, name, email, phone, department, pin,
                    monthlySalary, freeHolidaysAllowed, deductionMode, fixedDeductionPerDay,
                    status, createdAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)
                """,
                (
                    tid,
                    employee_id,
                    name,
                    str(body.get("email", "")),
                    str(body.get("phone", "")),
                    str(body.get("department", "Computer Science")),
                    str(body.get("pin", "1111")),
                    float(body.get("monthlySalary", 42000)),
                    int(body.get("freeHolidaysAllowed", 4)),
                    "fixed" if body.get("deductionMode") == "fixed" else "pro_rata",
                    float(body.get("fixedDeductionPerDay", 1400)),
                    now,
                ),
            )
            conn.commit()
            return jsonify({"ok": True, "id": tid}), 201
        finally:
            conn.close()

    @app.route("/api/teachers/<teacher_id>", methods=["PUT", "DELETE"])
    def manage_teacher(teacher_id: str):
        if get_role() != "admin":
            return jsonify({"error": "Only Admin Panel can edit faculty records."}), 403
        conn = db_conn()
        try:
            existing = conn.execute("SELECT * FROM teachers WHERE id = ?", (teacher_id,)).fetchone()
            if not existing:
                return jsonify({"error": "Teacher not found."}), 404
            if request.method == "DELETE":
                conn.execute("DELETE FROM teachers WHERE id = ?", (teacher_id,))
                conn.commit()
                return jsonify({"ok": True})

            body = request.get_json(silent=True) or {}
            conn.execute(
                """
                UPDATE teachers
                SET employeeId = ?, name = ?, email = ?, phone = ?, department = ?,
                    monthlySalary = ?, freeHolidaysAllowed = ?, deductionMode = ?, fixedDeductionPerDay = ?
                WHERE id = ?
                """,
                (
                    str(body.get("employeeId", existing["employeeId"])).strip().upper(),
                    str(body.get("name", existing["name"])).strip(),
                    str(body.get("email", existing["email"])),
                    str(body.get("phone", existing["phone"])),
                    str(body.get("department", existing["department"])),
                    float(body.get("monthlySalary", existing["monthlySalary"])),
                    int(body.get("freeHolidaysAllowed", existing["freeHolidaysAllowed"])),
                    body.get("deductionMode")
                    if body.get("deductionMode") in ("fixed", "pro_rata")
                    else existing["deductionMode"],
                    float(body.get("fixedDeductionPerDay", existing["fixedDeductionPerDay"])),
                    teacher_id,
                ),
            )
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.route("/api/teacher-attendance", methods=["PUT"])
    def update_teacher_attendance():
        if get_role() != "admin":
            return jsonify({"error": "Only Admin Panel can mark teacher holidays & attendance."}), 403
        body = request.get_json(silent=True) or {}
        teacher_id = body.get("teacherId")
        att_date = body.get("date")
        status = body.get("status")
        note = str(body.get("note", ""))

        if not teacher_id or not att_date or status not in (
            "present",
            "holiday",
            "half_holiday",
            "inst_off",
            "clear",
        ):
            return jsonify({"error": "Valid teacherId, date, and status are required."}), 400

        conn = db_conn()
        try:
            if status == "clear":
                conn.execute(
                    "DELETE FROM teacher_attendance WHERE teacherId = ? AND date = ?",
                    (teacher_id, att_date),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO teacher_attendance (id, teacherId, date, status, note, updatedAt)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(teacherId, date) DO UPDATE SET
                        status = excluded.status,
                        note = excluded.note,
                        updatedAt = excluded.updatedAt
                    """,
                    (
                        create_id("ta"),
                        teacher_id,
                        att_date,
                        status,
                        note,
                        datetime.now(UTC).isoformat(),
                    ),
                )
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.route("/api/students", methods=["POST"])
    def create_student():
        if get_role() != "admin":
            return jsonify({"error": "Only Admin Panel can enroll new students."}), 403
        body = request.get_json(silent=True) or {}
        name = str(body.get("name", "")).strip()
        roll_no = str(body.get("rollNo", "")).strip().upper()
        class_grade = str(body.get("classGrade", "B.Tech CS • Sem 3")).strip()
        if not name or not roll_no:
            return jsonify({"error": "Student name and Roll Number are required."}), 400

        st_id = create_id("stu")
        now = datetime.now(UTC).isoformat()
        total_fees = float(body.get("totalFees", 45000))
        fees_paid = float(body.get("feesPaid", 0))

        conn = db_conn()
        try:
            conn.execute(
                """
                INSERT INTO students (
                    id, rollNo, name, classGrade, email, phone, guardianName, guardianPhone,
                    totalFees, feesPaid, feeDueDate, createdAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    st_id,
                    roll_no,
                    name,
                    class_grade,
                    str(body.get("email", "")),
                    str(body.get("phone", "")),
                    str(body.get("guardianName", "")),
                    str(body.get("guardianPhone", "")),
                    total_fees,
                    fees_paid,
                    str(body.get("feeDueDate", "2026-11-30")),
                    now,
                ),
            )
            subject_ids = body.get("subjectIds")
            if not isinstance(subject_ids, list):
                student_sub_rows = conn.execute(
                    "SELECT id FROM subjects WHERE classGrade = ?",
                    (class_grade,),
                ).fetchall()
                subject_ids = [r["id"] for r in student_sub_rows]
                if not subject_ids:
                    subject_ids = [
                        r["id"] for r in conn.execute("SELECT id FROM subjects").fetchall()
                    ]
            for sub_id in subject_ids:
                conn.execute(
                    "INSERT OR IGNORE INTO student_subjects (studentId, subjectId) VALUES (?, ?)",
                    (st_id, sub_id),
                )
            if fees_paid > 0:
                conn.execute(
                    """
                    INSERT INTO fee_payments (
                        id, studentId, amount, paidOn, method, note, receiptNo, recordedBy
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        create_id("pay"),
                        st_id,
                        fees_paid,
                        date.today().isoformat(),
                        "UPI",
                        "Initial Fee Payment",
                        f"REC-{roll_no}-{int(datetime.now(UTC).timestamp()) % 10000}",
                        "Admin",
                    ),
                )
            conn.commit()
            return jsonify({"ok": True, "id": st_id}), 201
        finally:
            conn.close()

    @app.route("/api/students/<student_id>", methods=["PUT", "DELETE"])
    def manage_student(student_id: str):
        if get_role() != "admin":
            return jsonify({"error": "Only Admin Panel can update student records."}), 403
        conn = db_conn()
        try:
            existing = conn.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
            if not existing:
                return jsonify({"error": "Student not found."}), 404
            if request.method == "DELETE":
                conn.execute("DELETE FROM students WHERE id = ?", (student_id,))
                conn.commit()
                return jsonify({"ok": True})

            body = request.get_json(silent=True) or {}
            conn.execute(
                """
                UPDATE students
                SET rollNo = ?, name = ?, classGrade = ?, email = ?, phone = ?,
                    guardianName = ?, guardianPhone = ?, totalFees = ?, feeDueDate = ?
                WHERE id = ?
                """,
                (
                    str(body.get("rollNo", existing["rollNo"])).strip().upper(),
                    str(body.get("name", existing["name"])).strip(),
                    str(body.get("classGrade", existing["classGrade"])).strip(),
                    str(body.get("email", existing["email"])),
                    str(body.get("phone", existing["phone"])),
                    str(body.get("guardianName", existing["guardianName"])),
                    str(body.get("guardianPhone", existing["guardianPhone"])),
                    float(body.get("totalFees", existing["totalFees"])),
                    str(body.get("feeDueDate", existing["feeDueDate"])),
                    student_id,
                ),
            )
            if isinstance(body.get("subjectIds"), list):
                conn.execute("DELETE FROM student_subjects WHERE studentId = ?", (student_id,))
                for sub_id in body["subjectIds"]:
                    conn.execute(
                        "INSERT OR IGNORE INTO student_subjects (studentId, subjectId) VALUES (?, ?)",
                        (student_id, sub_id),
                    )
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.route("/api/students/<student_id>/payments", methods=["POST"])
    def record_fee_payment(student_id: str):
        if get_role() != "admin":
            return jsonify({"error": "Only Admin Panel can record student fee payments."}), 403
        conn = db_conn()
        try:
            student = conn.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
            if not student:
                return jsonify({"error": "Student not found."}), 404

            body = request.get_json(silent=True) or {}
            amount = float(body.get("amount", 0))
            if amount <= 0:
                return jsonify({"error": "Payment amount must be greater than zero."}), 400

            new_paid = min(float(student["totalFees"]), float(student["feesPaid"]) + amount)
            paid_on = str(body.get("paidOn") or date.today().isoformat())
            receipt_no = f"REC-{student['rollNo']}-{int(datetime.now(UTC).timestamp()) % 100000}"

            conn.execute("UPDATE students SET feesPaid = ? WHERE id = ?", (new_paid, student_id))
            conn.execute(
                """
                INSERT INTO fee_payments (
                    id, studentId, amount, paidOn, method, note, receiptNo, recordedBy
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    create_id("pay"),
                    student_id,
                    amount,
                    paid_on,
                    str(body.get("method", "UPI")),
                    str(body.get("note", "Semester Fee Installment")),
                    receipt_no,
                    "Admin",
                ),
            )
            conn.commit()
            return jsonify({"ok": True, "receiptNo": receipt_no, "feesPaid": new_paid}), 201
        finally:
            conn.close()

    # ==================== TEACHER-ONLY ATTENDANCE MARKING ====================
    @app.route("/api/sessions", methods=["POST"])
    def create_session():
        if get_role() != "teacher":
            return (
                jsonify(
                    {
                        "error": (
                            "Only Teacher is permitted to take class sessions and mark "
                            "student attendance."
                        )
                    }
                ),
                403,
            )
        body = request.get_json(silent=True) or {}
        subject_id = body.get("subjectId")
        session_date = body.get("sessionDate")
        if not subject_id or not session_date:
            return jsonify({"error": "subjectId and sessionDate are required."}), 400

        conn = db_conn()
        try:
            subject = conn.execute("SELECT * FROM subjects WHERE id = ?", (subject_id,)).fetchone()
            if not subject:
                return jsonify({"error": "Subject class not found."}), 404

            max_row = conn.execute(
                """
                SELECT COALESCE(MAX(sessionNumber), 0) AS maxNum
                FROM class_sessions WHERE subjectId = ? AND sessionDate = ?
                """,
                (subject_id, session_date),
            ).fetchone()
            session_num = int(max_row["maxNum"]) + 1
            ses_id = create_id("ses")
            now = datetime.now(UTC).isoformat()
            teacher_id = body.get("teacherId") or subject["teacherId"]
            topic = str(body.get("topic") or f"Lecture {session_num}").strip()

            conn.execute(
                """
                INSERT INTO class_sessions (
                    id, subjectId, teacherId, sessionDate, sessionNumber, topic, createdAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (ses_id, subject_id, teacher_id, session_date, session_num, topic, now),
            )

            records = body.get("records")
            if isinstance(records, list):
                for rec in records:
                    st_id = rec.get("studentId")
                    status = rec.get("status")
                    if st_id and status in ("present", "absent", "leave"):
                        conn.execute(
                            """
                            INSERT INTO student_attendance (
                                id, sessionId, studentId, status, remark, markedByTeacherId, updatedAt
                            ) VALUES (?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(sessionId, studentId) DO UPDATE SET
                                status = excluded.status,
                                remark = excluded.remark,
                                markedByTeacherId = excluded.markedByTeacherId,
                                updatedAt = excluded.updatedAt
                            """,
                            (
                                create_id("sa"),
                                ses_id,
                                st_id,
                                status,
                                str(rec.get("remark", "")),
                                teacher_id,
                                now,
                            ),
                        )
            conn.commit()
            session = dict(
                conn.execute("SELECT * FROM class_sessions WHERE id = ?", (ses_id,)).fetchone()
            )
            return jsonify({"session": session}), 201
        finally:
            conn.close()

    @app.route("/api/sessions/<session_id>/attendance", methods=["POST"])
    def save_session_attendance(session_id: str):
        if get_role() != "teacher":
            return (
                jsonify({"error": "Only Teacher can mark student Present, Absent, or Leave."}),
                403,
            )
        conn = db_conn()
        try:
            session = conn.execute(
                "SELECT * FROM class_sessions WHERE id = ?", (session_id,)
            ).fetchone()
            if not session:
                return jsonify({"error": "Class session not found."}), 404

            body = request.get_json(silent=True) or {}
            records = body.get("records") or []
            teacher_id = body.get("teacherId") or session["teacherId"]
            now = datetime.now(UTC).isoformat()

            if "topic" in body and body["topic"] is not None:
                conn.execute(
                    "UPDATE class_sessions SET topic = ? WHERE id = ?",
                    (str(body["topic"]), session_id),
                )

            saved = 0
            for rec in records:
                st_id = rec.get("studentId")
                status = rec.get("status")
                if not st_id or status not in ("present", "absent", "leave"):
                    continue
                conn.execute(
                    """
                    INSERT INTO student_attendance (
                        id, sessionId, studentId, status, remark, markedByTeacherId, updatedAt
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(sessionId, studentId) DO UPDATE SET
                        status = excluded.status,
                        remark = excluded.remark,
                        markedByTeacherId = excluded.markedByTeacherId,
                        updatedAt = excluded.updatedAt
                    """,
                    (
                        create_id("sa"),
                        session_id,
                        st_id,
                        status,
                        str(rec.get("remark", "")),
                        teacher_id,
                        now,
                    ),
                )
                saved += 1
            conn.commit()
            return jsonify({"ok": True, "count": saved})
        finally:
            conn.close()

    @app.route("/api/sessions/<session_id>", methods=["DELETE"])
    def delete_session(session_id: str):
        if get_role() != "teacher":
            return (
                jsonify({"error": "Only Teacher can remove a class attendance session."}),
                403,
            )
        conn = db_conn()
        try:
            conn.execute("DELETE FROM class_sessions WHERE id = ?", (session_id,))
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    @app.route("/api/student-attendance/cell", methods=["PUT"])
    def update_student_attendance_cell():
        if get_role() != "teacher":
            return (
                jsonify({"error": "Only Teacher can mark student Present, Absent, or Leave."}),
                403,
            )
        body = request.get_json(silent=True) or {}
        session_id = body.get("sessionId")
        student_id = body.get("studentId")
        status = body.get("status")
        if not session_id or not student_id or status not in ("present", "absent", "leave"):
            return jsonify({"error": "Valid sessionId, studentId, and status are required."}), 400

        conn = db_conn()
        try:
            conn.execute(
                """
                INSERT INTO student_attendance (
                    id, sessionId, studentId, status, remark, markedByTeacherId, updatedAt
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(sessionId, studentId) DO UPDATE SET
                    status = excluded.status,
                    remark = excluded.remark,
                    markedByTeacherId = excluded.markedByTeacherId,
                    updatedAt = excluded.updatedAt
                """,
                (
                    create_id("sa"),
                    session_id,
                    student_id,
                    status,
                    str(body.get("remark", "")),
                    body.get("teacherId"),
                    datetime.now(UTC).isoformat(),
                ),
            )
            conn.commit()
            return jsonify({"ok": True})
        finally:
            conn.close()

    # ==================== CSV EXPORTS ====================
    @app.route("/api/export/student-attendance.csv", methods=["GET"])
    def export_student_attendance_csv():
        month = request.args.get("month", "2026-11")
        subject_id = request.args.get("subjectId", "all")
        conn = db_conn()
        try:
            data = build_bootstrap_payload(conn, month)
        finally:
            conn.close()

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            [
                "Roll No",
                "Student Name",
                "Class",
                "Subject Filter",
                "Present",
                "Absent",
                "Leave",
                "Total Classes",
                "Ratio",
                "Attendance %",
                "Fees Left",
            ]
        )
        for st in data["students"]:
            summary = data["studentSummaries"][st["id"]]
            att = (
                summary["bySubject"].get(
                    subject_id,
                    {
                        "presentCount": 0,
                        "absentCount": 0,
                        "leaveCount": 0,
                        "totalClasses": 0,
                        "ratio": "0/0",
                        "percentage": None,
                    },
                )
                if subject_id != "all"
                else summary["attendance"]
            )
            fees = summary["fees"]
            writer.writerow(
                [
                    st["rollNo"],
                    st["name"],
                    st["classGrade"],
                    subject_id,
                    att["presentCount"],
                    att["absentCount"],
                    att["leaveCount"],
                    att["totalClasses"],
                    att["ratio"],
                    f"{att['percentage']}%" if att["percentage"] is not None else "N/A",
                    fees["feesLeft"],
                ]
            )
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename=class_records_attendance_{month}.csv"
            },
        )

    @app.route("/api/export/teacher-payroll.csv", methods=["GET"])
    def export_teacher_payroll_csv():
        month = request.args.get("month", "2026-11")
        conn = db_conn()
        try:
            data = build_bootstrap_payload(conn, month)
        finally:
            conn.close()

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            [
                "Faculty ID",
                "Name",
                "Department",
                "Monthly Salary",
                "Holidays Taken",
                "Free Holidays Allowed",
                "Extra Holidays (>4)",
                "Per-Day Deduction",
                "Total Money Deducted",
                "Net Payable Salary",
            ]
        )
        for t in data["teachers"]:
            p = data["teacherPayrolls"][t["id"]]
            writer.writerow(
                [
                    t["employeeId"],
                    t["name"],
                    t["department"],
                    p["monthlySalary"],
                    p["holidaysTaken"],
                    p["freeHolidaysAllowed"],
                    p["excessHolidays"],
                    p["perDayDeduction"],
                    p["deductionAmount"],
                    p["netSalary"],
                ]
            )
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename=class_records_teacher_payroll_{month}.csv"
            },
        )

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5050))
    print("=" * 64)
    print("  CLASS RECORDS  |  THE SHIVAGROUPS OF APP")
    print("  Developed by: RUDRAKSH GARG")
    print(f"  Running at:   http://127.0.0.1:{port}")
    print("=" * 64)
    app.run(host="127.0.0.1", port=port, debug=False)

"""Pure Python calculation engine for CLASS RECORDS.

Handles:
1. Student attendance ratio & percentage (e.g. 0/1 -> 0%, 1/2 -> 50%).
2. Leave penalty weighting ("less percentage minus when student doesn't come").
3. Teacher 1-month holiday counting & salary deduction on > 4 holidays.
4. Student college fee balance & overdue status.
"""

from __future__ import annotations

import calendar
from typing import Any


def get_days_in_month(month_str: str) -> int:
    """Return number of calendar days for a YYYY-MM string."""
    try:
        year_s, mon_s = month_str.split("-")
        year, mon = int(year_s), int(mon_s)
        return calendar.monthrange(year, mon)[1]
    except (ValueError, AttributeError):
        return 30


def calculate_student_attendance(
    records: list[dict[str, Any]], leave_credit_weight: str = "0.5"
) -> dict[str, Any]:
    """Calculate present, absent, leave counts, effective ratio, and percentage.

    Example:
      - 1 class held, student marked Absent  -> 0/1 (0.0%)
      - 2nd class held, student marked Present -> 1/2 (50.0%)
      - Approved Leave applies reduced minus via `leave_credit_weight` (default 0.5)
    """
    present_count = 0
    absent_count = 0
    leave_count = 0

    for row in records:
        status = row.get("status")
        if status == "present":
            present_count += 1
        elif status == "absent":
            absent_count += 1
        elif status == "leave":
            leave_count += 1

    total_classes = present_count + absent_count + leave_count
    is_excluded = str(leave_credit_weight) == "exclude"

    if is_excluded:
        effective_attended = float(present_count)
        effective_total = present_count + absent_count
    else:
        try:
            weight = float(leave_credit_weight)
        except (TypeError, ValueError):
            weight = 0.5
        effective_attended = round(present_count + (leave_count * weight), 2)
        effective_total = total_classes

    percentage = (
        round((effective_attended / effective_total) * 100.0, 1)
        if effective_total > 0
        else None
    )

    if effective_attended.is_integer():
        attended_label = str(int(effective_attended))
    else:
        attended_label = f"{effective_attended:.2f}".rstrip("0").rstrip(".")

    return {
        "presentCount": present_count,
        "absentCount": absent_count,
        "leaveCount": leave_count,
        "totalClasses": total_classes,
        "effectiveAttended": effective_attended,
        "effectiveTotal": effective_total,
        "ratio": f"{attended_label}/{effective_total}",
        "rawRatio": f"{present_count}/{total_classes}",
        "percentage": percentage,
    }


def calculate_teacher_payroll(
    teacher: dict[str, Any],
    month_str: str,
    attendance_rows: list[dict[str, Any]],
    default_free_limit: int = 4,
) -> dict[str, Any]:
    """Calculate 1-month teacher attendance and deduction for > 4 holidays."""
    days_in_month = get_days_in_month(month_str)
    present_days = 0
    full_holidays = 0
    half_holidays = 0
    inst_off_days = 0

    for row in attendance_rows:
        status = row.get("status")
        if status == "present":
            present_days += 1
        elif status == "holiday":
            full_holidays += 1
        elif status == "half_holiday":
            half_holidays += 1
        elif status == "inst_off":
            inst_off_days += 1

    holidays_taken = round(full_holidays + (half_holidays * 0.5), 2)
    free_limit = int(
        teacher.get("freeHolidaysAllowed")
        if teacher.get("freeHolidaysAllowed") is not None
        else default_free_limit
    )
    excess_holidays = round(max(0.0, holidays_taken - free_limit), 2)

    monthly_salary = float(teacher.get("monthlySalary") or 0.0)
    deduction_mode = teacher.get("deductionMode") or "pro_rata"

    if deduction_mode == "fixed":
        per_day_deduction = round(float(teacher.get("fixedDeductionPerDay") or 0.0), 2)
    else:
        per_day_deduction = round(monthly_salary / days_in_month, 2)

    deduction_amount = round(excess_holidays * per_day_deduction, 2)
    net_salary = round(max(0.0, monthly_salary - deduction_amount), 2)

    return {
        "daysInMonth": days_in_month,
        "presentDays": present_days,
        "fullHolidays": full_holidays,
        "halfHolidays": half_holidays,
        "instOffDays": inst_off_days,
        "holidaysTaken": holidays_taken,
        "freeHolidaysAllowed": free_limit,
        "excessHolidays": excess_holidays,
        "perDayDeduction": per_day_deduction,
        "deductionAmount": deduction_amount,
        "monthlySalary": round(monthly_salary, 2),
        "netSalary": net_salary,
    }


def calculate_teacher_yearly_payroll(
    teacher: dict[str, Any],
    year_str: str,
    attendance_rows_by_month: dict[str, list[dict[str, Any]]],
    default_free_limit: int = 4,
) -> dict[str, Any]:
    """Calculate full 1-year (12-month) teacher payroll with monthly breakdown and annual totals."""
    monthly_details: dict[str, dict[str, Any]] = {}
    annual_gross = 0.0
    annual_holidays = 0.0
    annual_excess = 0.0
    annual_deduction = 0.0
    annual_net = 0.0

    for m in range(1, 13):
        m_str = f"{year_str}-{m:02d}"
        rows = attendance_rows_by_month.get(m_str, [])
        p = calculate_teacher_payroll(teacher, m_str, rows, default_free_limit)
        monthly_details[m_str] = p
        annual_gross += p["monthlySalary"]
        annual_holidays += p["holidaysTaken"]
        annual_excess += p["excessHolidays"]
        annual_deduction += p["deductionAmount"]
        annual_net += p["netSalary"]

    return {
        "year": year_str,
        "annualGrossSalary": round(annual_gross, 2),
        "annualHolidaysTaken": round(annual_holidays, 2),
        "annualExcessHolidays": round(annual_excess, 2),
        "annualDeduction": round(annual_deduction, 2),
        "annualNetSalary": round(annual_net, 2),
        "months": monthly_details,
    }


def calculate_student_yearly_attendance(
    records_by_month: dict[str, list[dict[str, Any]]],
    leave_credit_weight: str = "0.5",
) -> dict[str, Any]:
    """Calculate full 1-year student attendance with 12-month breakdown and annual total percentage."""
    all_records: list[dict[str, Any]] = []
    month_summaries: dict[str, dict[str, Any]] = {}

    for m_str, rows in records_by_month.items():
        all_records.extend(rows)
        month_summaries[m_str] = calculate_student_attendance(rows, leave_credit_weight)

    annual_stats = calculate_student_attendance(all_records, leave_credit_weight)
    return {
        "annual": annual_stats,
        "monthlyBreakdown": month_summaries,
    }


def calculate_student_fees(student: dict[str, Any], today_iso: str) -> dict[str, Any]:
    """Calculate total fees, paid amount, remaining fees left, and overdue status."""
    total_fees = round(float(student.get("totalFees") or 0.0), 2)
    fees_paid = round(float(student.get("feesPaid") or 0.0), 2)
    fees_left = round(max(0.0, total_fees - fees_paid), 2)

    if fees_left == 0:
        status = "paid"
    elif fees_paid > 0:
        status = "partial"
    else:
        status = "unpaid"

    due_date = str(student.get("feeDueDate") or "")
    is_overdue = bool(fees_left > 0 and due_date and due_date < today_iso)

    return {
        "totalFees": total_fees,
        "feesPaid": fees_paid,
        "feesLeft": fees_left,
        "status": status,
        "isOverdue": is_overdue,
    }

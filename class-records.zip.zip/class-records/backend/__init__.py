"""Backend package for CLASS RECORDS college attendance & payroll management."""

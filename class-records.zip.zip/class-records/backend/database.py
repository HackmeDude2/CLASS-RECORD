"""SQLite3 database layer and initial college seed dataset for CLASS RECORDS."""

from __future__ import annotations

import calendar
import os
import secrets
import sqlite3
from datetime import UTC, date, datetime
from typing import Any

from backend.calculations import (
    calculate_student_attendance,
    calculate_student_fees,
    calculate_student_yearly_attendance,
    calculate_teacher_payroll,
    calculate_teacher_yearly_payroll,
    get_days_in_month,
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
DEFAULT_DB_PATH = os.path.join(DATA_DIR, "class_records.db")


def create_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(5)}"


def get_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db(db_path: str = DEFAULT_DB_PATH, seed: bool = True) -> None:
    conn = get_connection(db_path)
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS teachers (
                id TEXT PRIMARY KEY,
                employeeId TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                email TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                department TEXT DEFAULT '',
                pin TEXT NOT NULL DEFAULT '1111',
                monthlySalary REAL NOT NULL DEFAULT 42000,
                freeHolidaysAllowed INTEGER NOT NULL DEFAULT 4,
                deductionMode TEXT NOT NULL DEFAULT 'pro_rata',
                fixedDeductionPerDay REAL NOT NULL DEFAULT 1400,
                status TEXT NOT NULL DEFAULT 'active',
                createdAt TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS subjects (
                id TEXT PRIMARY KEY,
                code TEXT NOT NULL,
                name TEXT NOT NULL,
                classGrade TEXT NOT NULL,
                teacherId TEXT REFERENCES teachers(id) ON DELETE SET NULL,
                scheduleNote TEXT DEFAULT '',
                accentColor TEXT DEFAULT '#D4AF37',
                createdAt TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS students (
                id TEXT PRIMARY KEY,
                rollNo TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                classGrade TEXT NOT NULL,
                email TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                guardianName TEXT DEFAULT '',
                guardianPhone TEXT DEFAULT '',
                totalFees REAL NOT NULL DEFAULT 45000,
                feesPaid REAL NOT NULL DEFAULT 0,
                feeDueDate TEXT DEFAULT '',
                createdAt TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS student_subjects (
                studentId TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                subjectId TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
                PRIMARY KEY (studentId, subjectId)
            );

            CREATE TABLE IF NOT EXISTS fee_payments (
                id TEXT PRIMARY KEY,
                studentId TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                amount REAL NOT NULL,
                paidOn TEXT NOT NULL,
                method TEXT NOT NULL DEFAULT 'UPI',
                note TEXT DEFAULT '',
                receiptNo TEXT NOT NULL,
                recordedBy TEXT DEFAULT 'Admin'
            );

            CREATE TABLE IF NOT EXISTS class_sessions (
                id TEXT PRIMARY KEY,
                subjectId TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
                teacherId TEXT REFERENCES teachers(id) ON DELETE SET NULL,
                sessionDate TEXT NOT NULL,
                sessionNumber INTEGER NOT NULL DEFAULT 1,
                topic TEXT DEFAULT '',
                createdAt TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS student_attendance (
                id TEXT PRIMARY KEY,
                sessionId TEXT NOT NULL REFERENCES class_sessions(id) ON DELETE CASCADE,
                studentId TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                status TEXT NOT NULL CHECK (status IN ('present', 'absent', 'leave')),
                remark TEXT DEFAULT '',
                markedByTeacherId TEXT REFERENCES teachers(id) ON DELETE SET NULL,
                updatedAt TEXT NOT NULL,
                UNIQUE (sessionId, studentId)
            );

            CREATE TABLE IF NOT EXISTS teacher_attendance (
                id TEXT PRIMARY KEY,
                teacherId TEXT NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
                date TEXT NOT NULL,
                status TEXT NOT NULL CHECK (status IN ('present', 'holiday', 'half_holiday', 'inst_off')),
                note TEXT DEFAULT '',
                updatedAt TEXT NOT NULL,
                UNIQUE (teacherId, date)
            );
            """
        )
        conn.commit()
        if seed:
            seed_initial_data(conn)
    finally:
        conn.close()


def get_settings_map(conn: sqlite3.Connection) -> dict[str, str]:
    rows = conn.execute("SELECT key, value FROM settings").fetchall()
    return {row["key"]: row["value"] for row in rows}


def seed_initial_data(conn: sqlite3.Connection) -> None:
    count = conn.execute("SELECT COUNT(*) AS cnt FROM teachers").fetchone()["cnt"]
    if count > 0:
        return

    now = datetime.now(UTC).isoformat()

    default_settings = [
        ("institutionName", "Class Records College of Engineering"),
        ("departmentBanner", "B.Tech Computer Science • Semester III"),
        ("currency", "₹"),
        ("freeHolidaysLimit", "4"),
        ("leaveCreditWeight", "0.5"),
        ("minAttendanceTarget", "75"),
        ("adminPin", "1234"),
        ("teacherDefaultPin", "1111"),
    ]
    conn.executemany(
        "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
        default_settings,
    )

    teachers = [
        (
            "tch_meera",
            "FAC-101",
            "Prof. Meera Kapoor",
            "meera.kapoor@classrecords.edu",
            "+91 98110 33890",
            "Computer Science",
            "1111",
            48000,
            4,
            "pro_rata",
            1600,
        ),
        (
            "tch_aarav",
            "FAC-102",
            "Dr. Aarav Sharma",
            "aarav.sharma@classrecords.edu",
            "+91 98110 22410",
            "Algorithms & Mathematics",
            "1111",
            54000,
            4,
            "pro_rata",
            1800,
        ),
        (
            "tch_kabir",
            "FAC-103",
            "Mr. Kabir Verma",
            "kabir.verma@classrecords.edu",
            "+91 98110 44120",
            "Electronics & Humanities",
            "1111",
            42000,
            4,
            "fixed",
            1400,
        ),
    ]
    conn.executemany(
        """
        INSERT INTO teachers (
            id, employeeId, name, email, phone, department, pin,
            monthlySalary, freeHolidaysAllowed, deductionMode, fixedDeductionPerDay,
            status, createdAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)
        """,
        [(*t, now) for t in teachers],
    )

    subjects = [
        (
            "sub_py",
            "CS-301",
            "Python Programming",
            "B.Tech CS • Sem 3",
            "tch_meera",
            "Mon–Sat • 09:00 AM",
            "#D4AF37",
        ),
        (
            "sub_dsa",
            "CS-302",
            "Data Structures & Algorithms",
            "B.Tech CS • Sem 3",
            "tch_aarav",
            "Mon–Sat • 10:30 AM",
            "#60A5FA",
        ),
        (
            "sub_math",
            "MA-303",
            "Discrete Mathematics",
            "B.Tech CS • Sem 3",
            "tch_aarav",
            "Mon, Wed, Fri • 12:00 PM",
            "#A78BFA",
        ),
        (
            "sub_ec",
            "EC-304",
            "Digital Logic & Systems",
            "B.Tech CS • Sem 3",
            "tch_kabir",
            "Tue, Thu, Sat • 02:00 PM",
            "#34D399",
        ),
        (
            "sub_hs",
            "HS-305",
            "Technical Communication Lab",
            "B.Tech CS • Sem 3",
            "tch_kabir",
            "Thu, Sat • 03:30 PM",
            "#F472B6",
        ),
    ]
    conn.executemany(
        """
        INSERT INTO subjects (
            id, code, name, classGrade, teacherId, scheduleNote, accentColor, createdAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [(*s, now) for s in subjects],
    )

    students = [
        ("stu_01", "26CS01", "Ananya Deshmukh", "B.Tech CS • Sem 3", "ananya@college.edu", "+91 98765 00101", "Rajesh Deshmukh", "+91 98765 99101", 45000, 45000, "2026-11-10"),
        ("stu_02", "26CS02", "Rohan Malhotra", "B.Tech CS • Sem 3", "rohan@college.edu", "+91 98765 00102", "Vikram Malhotra", "+91 98765 99102", 45000, 25000, "2026-11-18"),
        ("stu_03", "26CS03", "Isha Rathore", "B.Tech CS • Sem 3", "isha@college.edu", "+91 98765 00103", "Sunita Rathore", "+91 98765 99103", 45000, 45000, "2026-11-10"),
        ("stu_04", "26CS04", "Vihaan Saxena", "B.Tech CS • Sem 3", "vihaan@college.edu", "+91 98765 00104", "Manoj Saxena", "+91 98765 99104", 45000, 15000, "2026-11-15"),
        ("stu_05", "26CS05", "Diya Chatterjee", "B.Tech CS • Sem 3", "diya@college.edu", "+91 98765 00105", "Subrata Chatterjee", "+91 98765 99105", 45000, 35000, "2026-12-05"),
        ("stu_06", "26CS06", "Arjun Nair", "B.Tech CS • Sem 3", "arjun@college.edu", "+91 98765 00106", "Prakash Nair", "+91 98765 99106", 45000, 0, "2026-11-12"),
        ("stu_07", "26CS07", "Sana Qureshi", "B.Tech CS • Sem 3", "sana@college.edu", "+91 98765 00107", "Tariq Qureshi", "+91 98765 99107", 45000, 45000, "2026-11-10"),
        ("stu_08", "26CS08", "Devansh Bansal", "B.Tech CS • Sem 3", "devansh@college.edu", "+91 98765 00108", "Nitin Bansal", "+91 98765 99108", 45000, 20000, "2026-11-28"),
        ("stu_09", "26CS09", "Kavya Joshi", "B.Tech CS • Sem 3", "kavya@college.edu", "+91 98765 00109", "Deepak Joshi", "+91 98765 99109", 45000, 45000, "2026-11-10"),
        ("stu_10", "26CS10", "Siddharth Mehta", "B.Tech CS • Sem 3", "siddharth@college.edu", "+91 98765 00110", "Alok Mehta", "+91 98765 99110", 45000, 0, "2026-11-14"),
    ]
    conn.executemany(
        """
        INSERT INTO students (
            id, rollNo, name, classGrade, email, phone, guardianName, guardianPhone,
            totalFees, feesPaid, feeDueDate, createdAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [(*st, now) for st in students],
    )

    for st in students:
        for sub in subjects:
            conn.execute(
                "INSERT INTO student_subjects (studentId, subjectId) VALUES (?, ?)",
                (st[0], sub[0]),
            )
        if st[9] > 0:
            conn.execute(
                """
                INSERT INTO fee_payments (
                    id, studentId, amount, paidOn, method, note, receiptNo, recordedBy
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    create_id("pay"),
                    st[0],
                    st[9],
                    "2026-11-04",
                    "UPI" if int(st[0].split("_")[1]) % 2 == 1 else "Bank Transfer",
                    "Semester III Tuition Payment",
                    f"REC-2611-{st[1]}",
                    "Admin",
                ),
            )

    # Full 1-Year Teacher & Student Attendance for Academic Year 2026 (Jan to Dec)
    teacher_yearly_holidays = {
        "tch_meera": {
            1: {8, 22},
            2: {12},
            3: {5, 19},
            4: {14},
            5: {2, 16, 28},
            6: {10},
            7: {4, 11, 18, 25, 29},  # 5 holidays -> 1 extra
            8: {15, 22},
            9: {9, 23},
            10: {2, 16, 30},
            11: {6, 14, 21},  # 3 holidays -> 0 deduction
            12: {10, 24},
        },
        "tch_aarav": {
            1: {10, 20},
            2: {14, 25},
            3: {4, 11, 18, 25, 28},  # 5 holidays -> 1 extra -> deduction
            4: {9, 23},
            5: {6, 20},
            6: {13, 27},
            7: {8, 22},
            8: {5, 19},
            9: {12, 26},
            10: {7, 21},
            11: {3, 4, 11, 12, 18, 24},  # 6 holidays -> 2 extra -> ₹3,600 deduction
            12: {9, 23},
        },
        "tch_kabir": {
            1: {15},
            2: {18},
            3: {12, 26},
            4: {16},
            5: {14, 21},
            6: {18},
            7: {16, 23},
            8: {6, 13, 20, 27, 29},  # 5 holidays -> 1 extra -> ₹1,400 deduction
            9: {17},
            10: {15, 29},
            11: {5, 10, 16, 19, 25},  # 5 holidays -> 1 extra -> ₹1,400 deduction
            12: {17, 31},
        },
    }

    # Seed teacher attendance for all 12 months of 2026
    for m in range(1, 13):
        days_in_m = calendar.monthrange(2026, m)[1]
        limit_day = 26 if m == 11 else days_in_m
        for t in teachers:
            tid = t[0]
            holidays_this_month = teacher_yearly_holidays.get(tid, {}).get(m, set())
            for day in range(1, limit_day + 1):
                date_str = f"2026-{m:02d}-{day:02d}"
                dow = date(2026, m, day).weekday()  # 6 = Sunday
                if dow == 6:
                    status, note = "inst_off", "Sunday College Off"
                elif day in holidays_this_month:
                    status, note = "holiday", "Personal Holiday"
                else:
                    status, note = "present", ""
                conn.execute(
                    """
                    INSERT INTO teacher_attendance (id, teacherId, date, status, note, updatedAt)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (create_id("ta"), tid, date_str, status, note, now),
                )

    def pick_status(stu_idx: int, ses_idx: int, seed_offset: int) -> str:
        if stu_idx in (0, 8):  # Ananya, Kavya ~95%
            return "leave" if (ses_idx == 5 and seed_offset == 1) else "present"
        if stu_idx == 1:  # Rohan ~76%
            if (ses_idx + seed_offset) % 7 == 0:
                return "leave"
            if (ses_idx + seed_offset) % 5 == 0:
                return "absent"
            return "present"
        if stu_idx == 2:  # Isha ~90%
            if ses_idx == 3 and seed_offset == 2:
                return "leave"
            return "absent" if (ses_idx + seed_offset) % 10 == 0 else "present"
        if stu_idx == 3:  # Vihaan ~62% warning
            if (ses_idx + seed_offset) % 3 == 0:
                return "absent"
            if (ses_idx + seed_offset) % 8 == 0:
                return "leave"
            return "present"
        if stu_idx == 4:  # Diya ~85%
            return "leave" if (ses_idx + seed_offset) % 6 == 0 else "present"
        if stu_idx == 5:  # Arjun ~52%
            return "absent" if (ses_idx + seed_offset) % 2 == 0 else "present"
        if stu_idx == 6:  # Sana ~93%
            return "leave" if (ses_idx + seed_offset) % 9 == 0 else "present"
        if stu_idx == 7:  # Devansh ~79%
            return "absent" if (ses_idx + seed_offset) % 5 == 0 else "present"
        # Siddharth ~66%
        if (ses_idx + seed_offset) % 4 == 0:
            return "absent"
        if (ses_idx + seed_offset) % 7 == 0:
            return "leave"
        return "present"

    # Seed academic sessions across months 1..10 (and 12) for Academic Year 2026
    # Month 11 (November 2026) is the special demo month with detailed schedule
    subject_topics = {
        "sub_py": [
            "Intro to Python & Syntax", "Control Flow & Loops", "Functions & Scoping",
            "Data Structures: Lists & Dicts", "Modules & Packages", "File Operations",
            "Exception Handling", "OOP Concepts & Classes", "Inheritance & Polymorphism",
            "Decorators & Generators", "Flask Web Framework", "RESTful Architecture",
            "SQLite & ORM", "Testing & Debugging"
        ],
        "sub_dsa": [
            "Time & Space Complexity", "Arrays & Strings", "Linked Lists",
            "Stacks & Expression Parsing", "Queues & Circular Buffers", "Recursion & Backtracking",
            "Binary Trees", "Binary Search Trees", "Heaps & Priority Queues",
            "Graph Representations", "BFS & DFS Traversal", "Shortest Path Algorithms",
            "Dynamic Programming Basics", "Greedy Techniques"
        ],
        "sub_math": [
            "Set Theory & Venn Diagrams", "Functions & Relations", "Propositional Logic",
            "Truth Tables & Proofs", "Combinatorics & Permutations", "Pigeonhole Principle",
            "Recurrence Relations", "Graph Theory Introduction", "Trees & Spanning Forests",
            "Boolean Algebra & Lattices"
        ],
        "sub_ec": [
            "Number Systems & Codes", "Logic Gates & Truth Tables", "K-Map Minimization",
            "Combinational Circuit Design", "Multiplexers & Encoders", "Sequential Circuit Basics",
            "SR & JK Flip-Flops", "D & T Flip-Flops", "Registers & Shift Registers",
            "Synchronous Counters"
        ],
    }

    # Generate sessions for other months of 2026 (Jan through Oct)
    global_ses_count = 0
    for m in range(1, 11):
        days_in_m = calendar.monthrange(2026, m)[1]
        # 4 sessions per subject per month across weekdays
        sub_list = [
            ("sub_py", "tch_meera", 1),
            ("sub_dsa", "tch_aarav", 2),
            ("sub_math", "tch_aarav", 3),
            ("sub_ec", "tch_kabir", 4),
        ]
        for sub_id, tch_id, offset in sub_list:
            # Pick 4 distinct non-Sunday days in this month
            class_days = [d for d in range(2, days_in_m - 1) if date(2026, m, d).weekday() != 6][::6][:4]
            topics = subject_topics.get(sub_id, ["Class Lecture"])
            for idx, day in enumerate(class_days):
                global_ses_count += 1
                ses_id = create_id("ses")
                date_str = f"2026-{m:02d}-{day:02d}"
                topic_title = topics[(m + idx) % len(topics)]
                conn.execute(
                    """
                    INSERT INTO class_sessions (id, subjectId, teacherId, sessionDate, sessionNumber, topic, createdAt)
                    VALUES (?, ?, ?, ?, 1, ?, ?)
                    """,
                    (ses_id, sub_id, tch_id, date_str, f"{topic_title} (Month {m})", now),
                )
                for s_idx, st in enumerate(students):
                    status = pick_status(s_idx, global_ses_count, offset)
                    conn.execute(
                        """
                        INSERT INTO student_attendance (id, sessionId, studentId, status, remark, markedByTeacherId, updatedAt)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (create_id("sa"), ses_id, st[0], status, "Approved Leave" if status == "leave" else "", tch_id, now),
                    )

    # Detailed November 2026 Sessions (Demo Semester Month)
    py_days = [2, 4, 6, 9, 11, 13, 16, 18, 20, 23, 25]
    py_topics = [
        "Python Data Model & Iterators", "List Comprehensions & Generators",
        "Decorators & Closures", "OOP & Dunder Methods",
        "File Handling & CSV/JSON", "SQLite3 Database Integration",
        "Exception Handling & Logging", "Flask Routing & Blueprints",
        "REST API Serialization", "Unit Testing with unittest",
        "Project Architecture Review",
    ]
    dsa_days = [3, 5, 7, 10, 12, 14, 17, 19, 21, 24]
    dsa_topics = [
        "Asymptotic Complexity", "Stacks & Monotonic Queues", "Doubly Linked Lists",
        "Binary Search Trees", "AVL Rotations", "Heap & Priority Queues",
        "Graph BFS & DFS", "Dijkstra Shortest Path", "Dynamic Programming I",
        "Trie & String Matching",
    ]
    math_days = [2, 4, 9, 11, 16, 18, 23, 25]
    math_topics = [
        "Propositional Logic", "Predicates & Quantifiers", "Relations & Equivalence",
        "Partial Orders & Hasse", "Combinatorics & Pigeonhole", "Recurrence Relations",
        "Graph Isomorphism", "Modular Arithmetic",
    ]

    def insert_subject_sessions(
        subject_id: str, teacher_id: str, days: list[int], topics: list[str], offset: int
    ) -> None:
        for idx, day in enumerate(days):
            ses_id = create_id("ses")
            date_str = f"2026-11-{day:02d}"
            conn.execute(
                """
                INSERT INTO class_sessions (
                    id, subjectId, teacherId, sessionDate, sessionNumber, topic, createdAt
                ) VALUES (?, ?, ?, ?, 1, ?, ?)
                """,
                (ses_id, subject_id, teacher_id, date_str, topics[idx % len(topics)], now),
            )
            for s_idx, st in enumerate(students):
                status = pick_status(s_idx, idx, offset)
                conn.execute(
                    """
                    INSERT INTO student_attendance (
                        id, sessionId, studentId, status, remark, markedByTeacherId, updatedAt
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        create_id("sa"),
                        ses_id,
                        st[0],
                        status,
                        "Approved Leave (Less % Minus)" if status == "leave" else "",
                        teacher_id,
                        now,
                    ),
                )

    insert_subject_sessions("sub_py", "tch_meera", py_days, py_topics, 1)
    insert_subject_sessions("sub_dsa", "tch_aarav", dsa_days, dsa_topics, 2)
    insert_subject_sessions("sub_math", "tch_aarav", math_days, math_topics, 3)

    # EC-304: 2 lectures on Nov 24 for instant 0/1 -> 1/2 (50%) demo!
    # HS-305: starts with 0 classes on Nov 26 for teacher to mark live demo!
    ec_ses_1 = "ses_ec_demo_1"
    ec_ses_2 = "ses_ec_demo_2"
    conn.execute(
        """
        INSERT INTO class_sessions (id, subjectId, teacherId, sessionDate, sessionNumber, topic, createdAt)
        VALUES (?, 'sub_ec', 'tch_kabir', '2026-11-24', 1, 'Boolean Algebra & K-Maps (Class 1)', ?)
        """,
        (ec_ses_1, now),
    )
    conn.execute(
        """
        INSERT INTO class_sessions (id, subjectId, teacherId, sessionDate, sessionNumber, topic, createdAt)
        VALUES (?, 'sub_ec', 'tch_kabir', '2026-11-24', 2, 'Flip-Flops & Sequential Logic (Class 2)', ?)
        """,
        (ec_ses_2, now),
    )
    ec_m1 = ["present", "absent", "present", "absent", "present", "absent", "present", "leave", "present", "absent"]
    ec_m2 = ["present", "present", "leave", "present", "present", "absent", "present", "present", "present", "present"]
    for idx, st in enumerate(students):
        conn.execute(
            """
            INSERT INTO student_attendance (id, sessionId, studentId, status, remark, markedByTeacherId, updatedAt)
            VALUES (?, ?, ?, ?, ?, 'tch_kabir', ?)
            """,
            (create_id("sa"), ec_ses_1, st[0], ec_m1[idx], "Medical Leave" if ec_m1[idx] == "leave" else "", now),
        )
        conn.execute(
            """
            INSERT INTO student_attendance (id, sessionId, studentId, status, remark, markedByTeacherId, updatedAt)
            VALUES (?, ?, ?, ?, ?, 'tch_kabir', ?)
            """,
            (create_id("sa"), ec_ses_2, st[0], ec_m2[idx], "Academic Leave" if ec_m2[idx] == "leave" else "", now),
        )

    conn.commit()


def build_bootstrap_payload(conn: sqlite3.Connection, month_str: str) -> dict[str, Any]:
    safe_year = "2026"
    is_annual_view = str(month_str).lower() == "all"
    safe_month = "all" if is_annual_view else (
        month_str if (month_str and len(month_str) == 7 and month_str[4] == "-") else "2026-11"
    )

    settings = get_settings_map(conn)
    leave_weight = settings.get("leaveCreditWeight", "0.5")
    global_free_limit = int(settings.get("freeHolidaysLimit", "4"))
    today_iso = date.today().isoformat()

    teachers_raw = [
        dict(row)
        for row in conn.execute("SELECT * FROM teachers ORDER BY employeeId ASC").fetchall()
    ]
    teachers = []
    for t in teachers_raw:
        t.pop("pin", None)
        teachers.append(t)

    subjects = [
        dict(row)
        for row in conn.execute("SELECT * FROM subjects ORDER BY code ASC").fetchall()
    ]
    students_raw = [
        dict(row)
        for row in conn.execute("SELECT * FROM students ORDER BY rollNo ASC").fetchall()
    ]
    enrollments = conn.execute("SELECT studentId, subjectId FROM student_subjects").fetchall()
    fee_payments = [
        dict(row)
        for row in conn.execute(
            "SELECT * FROM fee_payments ORDER BY paidOn DESC, receiptNo DESC"
        ).fetchall()
    ]

    # Fetch ALL academic sessions for the 1-Year Academic Period 2026
    all_year_sessions = [
        dict(row)
        for row in conn.execute(
            """
            SELECT * FROM class_sessions
            WHERE sessionDate LIKE '2026-%'
            ORDER BY sessionDate ASC, sessionNumber ASC
            """
        ).fetchall()
    ]
    all_year_session_ids = {s["id"] for s in all_year_sessions}

    # Fetch ALL student attendance records for the year
    all_year_student_attendance = [
        dict(row)
        for row in conn.execute("SELECT * FROM student_attendance").fetchall()
        if row["sessionId"] in all_year_session_ids
    ]

    # Fetch ALL teacher attendance records for the year
    all_year_teacher_attendance = [
        dict(row)
        for row in conn.execute(
            "SELECT * FROM teacher_attendance WHERE date LIKE '2026-%' ORDER BY date ASC"
        ).fetchall()
    ]

    student_subjects_map: dict[str, list[str]] = {}
    for row in enrollments:
        student_subjects_map.setdefault(row["studentId"], []).append(row["subjectId"])

    students = []
    for st in students_raw:
        st["subjectIds"] = student_subjects_map.get(st["id"], [])
        students.append(st)

    # 12 Months list for Academic Year 2026
    months_list = [
        {
            "key": f"2026-{m:02d}",
            "name": calendar.month_name[m],
            "short": calendar.month_abbr[m],
            "month": m,
            "year": 2026,
            "daysCount": calendar.monthrange(2026, m)[1],
        }
        for m in range(1, 13)
    ]

    # Pre-index student attendance by studentId and sessionId
    att_by_student_and_session: dict[str, dict[str, dict[str, Any]]] = {}
    for row in all_year_student_attendance:
        att_by_student_and_session.setdefault(row["studentId"], {})[row["sessionId"]] = row

    # Pre-group sessions by month and by subject
    sessions_by_month: dict[str, list[dict[str, Any]]] = {m["key"]: [] for m in months_list}
    sessions_by_subject: dict[str, list[dict[str, Any]]] = {s["id"]: [] for s in subjects}
    for s in all_year_sessions:
        m_prefix = s["sessionDate"][:7]
        if m_prefix in sessions_by_month:
            sessions_by_month[m_prefix].append(s)
        if s["subjectId"] in sessions_by_subject:
            sessions_by_subject[s["subjectId"]].append(s)

    # Pre-group teacher attendance by teacher and month
    teacher_att_by_month: dict[str, dict[str, list[dict[str, Any]]]] = {
        t["id"]: {m["key"]: [] for m in months_list} for t in teachers
    }
    for ta in all_year_teacher_attendance:
        m_prefix = ta["date"][:7]
        tid = ta["teacherId"]
        if tid in teacher_att_by_month and m_prefix in teacher_att_by_month[tid]:
            teacher_att_by_month[tid][m_prefix].append(ta)

    # Compute ANNUAL 1-Year summaries for all students
    annual_student_summaries: dict[str, dict[str, Any]] = {}
    for st in students:
        sid = st["id"]
        st_all_rows = list(att_by_student_and_session.get(sid, {}).values())
        overall_annual = calculate_student_attendance(st_all_rows, leave_weight)

        # 12-Month breakdown
        monthly_breakdown: dict[str, dict[str, Any]] = {}
        for m in months_list:
            m_key = m["key"]
            m_ses_ids = {s["id"] for s in sessions_by_month.get(m_key, [])}
            m_rows = [r for r in st_all_rows if r["sessionId"] in m_ses_ids]
            monthly_breakdown[m_key] = calculate_student_attendance(m_rows, leave_weight)

        # Subject-wise 1-Year summary
        by_subject_annual: dict[str, dict[str, Any]] = {}
        for sub_id in st["subjectIds"]:
            sub_ses_ids = {s["id"] for s in sessions_by_subject.get(sub_id, [])}
            sub_rows = [r for r in st_all_rows if r["sessionId"] in sub_ses_ids]
            by_subject_annual[sub_id] = calculate_student_attendance(sub_rows, leave_weight)

        annual_student_summaries[sid] = {
            "annual": overall_annual,
            "monthlyBreakdown": monthly_breakdown,
            "bySubject": by_subject_annual,
            "fees": calculate_student_fees(st, today_iso),
        }

    # Compute ANNUAL 1-Year payroll for all teachers
    annual_teacher_payrolls: dict[str, dict[str, Any]] = {}
    for t in teachers:
        annual_teacher_payrolls[t["id"]] = calculate_teacher_yearly_payroll(
            t, safe_year, teacher_att_by_month.get(t["id"], {}), global_free_limit
        )

    # Selected scope sessions & attendance
    if is_annual_view:
        active_sessions = all_year_sessions
        active_student_attendance = all_year_student_attendance
        active_teacher_attendance = all_year_teacher_attendance
        active_days_count = 365
        active_teacher_payrolls = {
            t["id"]: {
                "daysInMonth": 365,
                "monthlySalary": annual_teacher_payrolls[t["id"]]["annualGrossSalary"],
                "holidaysTaken": annual_teacher_payrolls[t["id"]]["annualHolidaysTaken"],
                "excessHolidays": annual_teacher_payrolls[t["id"]]["annualExcessHolidays"],
                "deductionAmount": annual_teacher_payrolls[t["id"]]["annualDeduction"],
                "netSalary": annual_teacher_payrolls[t["id"]]["annualNetSalary"],
                "perDayDeduction": round(annual_teacher_payrolls[t["id"]]["annualDeduction"] / max(1.0, annual_teacher_payrolls[t["id"]]["annualExcessHolidays"]), 2) if annual_teacher_payrolls[t["id"]]["annualExcessHolidays"] > 0 else 0.0,
            }
            for t in teachers
        }
        active_student_summaries = {
            st["id"]: {
                "attendance": annual_student_summaries[st["id"]]["annual"],
                "bySubject": annual_student_summaries[st["id"]]["bySubject"],
                "fees": annual_student_summaries[st["id"]]["fees"],
            }
            for st in students
        }
    else:
        active_sessions = [s for s in all_year_sessions if s["sessionDate"].startswith(f"{safe_month}-")]
        m_ses_ids = {s["id"] for s in active_sessions}
        active_student_attendance = [
            r for r in all_year_student_attendance if r["sessionId"] in m_ses_ids
        ]
        active_teacher_attendance = [
            r for r in all_year_teacher_attendance if r["date"].startswith(f"{safe_month}-")
        ]
        active_days_count = get_days_in_month(safe_month)

        active_teacher_payrolls = {}
        for t in teachers:
            t_rows = [r for r in active_teacher_attendance if r["teacherId"] == t["id"]]
            active_teacher_payrolls[t["id"]] = calculate_teacher_payroll(
                t, safe_month, t_rows, global_free_limit
            )

        active_student_summaries = {}
        for st in students:
            st_rows = [r for r in active_student_attendance if r["studentId"] == st["id"]]
            overall = calculate_student_attendance(st_rows, leave_weight)
            by_sub = {}
            for sub_id in st["subjectIds"]:
                sub_ses_ids = {s["id"] for s in active_sessions if s["subjectId"] == sub_id}
                sub_rows = [r for r in st_rows if r["sessionId"] in sub_ses_ids]
                by_sub[sub_id] = calculate_student_attendance(sub_rows, leave_weight)
            active_student_summaries[st["id"]] = {
                "attendance": overall,
                "bySubject": by_sub,
                "fees": calculate_student_fees(st, today_iso),
            }

    return {
        "academicYear": safe_year,
        "month": safe_month,
        "isAnnualView": is_annual_view,
        "monthsList": months_list,
        "daysInMonth": active_days_count,
        "settings": settings,
        "teachers": teachers,
        "subjects": subjects,
        "students": students,
        "sessions": active_sessions,
        "studentAttendance": active_student_attendance,
        "teacherAttendance": active_teacher_attendance,
        "feePayments": fee_payments,
        "teacherPayrolls": active_teacher_payrolls,
        "studentSummaries": active_student_summaries,
        "annualStudentSummaries": annual_student_summaries,
        "annualTeacherPayrolls": annual_teacher_payrolls,
    }

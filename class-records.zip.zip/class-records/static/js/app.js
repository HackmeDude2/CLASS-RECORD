/* CLASS RECORDS — Frontend Controller
 * Company: THE SHIVAGROUPS OF APP
 * Developed By: RUDRAKSH GARG
 */

/* ════════════════════════════════════════════════════════
   PORTAL AUTH SYSTEM
   3 portals: Teacher (password), Admin (PIN), Student (name select)
════════════════════════════════════════════════════════ */

let _loginRole = null;      // which portal we're opening
let _loginTeacherId = null; // for teacher login
let _loginStudentId = null; // for student login
let _pinBuffer = '';        // 4-digit PIN input buffer

function openLoginModal(role) {
  _loginRole = role;
  _pinBuffer = '';
  const overlay = document.getElementById('loginOverlay');
  const box = document.getElementById('loginBox');

  if (role === 'teacher') {
    box.innerHTML = buildTeacherLoginHTML();
    overlay.classList.add('visible');
    // wire teacher select
    const sel = document.getElementById('teacherLoginSelect');
    if (sel) sel.onchange = e => { _loginTeacherId = e.target.value; };
    _loginTeacherId = sel ? sel.value : '';
    document.getElementById('teacherLoginBtn').onclick = doTeacherLogin;
    document.getElementById('loginBackBtn').onclick = closeLoginModal;
  } else if (role === 'admin') {
    box.innerHTML = buildAdminLoginHTML();
    overlay.classList.add('visible');
    updatePinDots();
    wirePinPad('adminPinInput', 'adminPinDots');
    document.getElementById('adminLoginBtn').onclick = doAdminLogin;
    document.getElementById('loginBackBtn').onclick = closeLoginModal;
  } else if (role === 'student') {
    box.innerHTML = buildStudentLoginHTML();
    overlay.classList.add('visible');
    const sel = document.getElementById('studentLoginSelect');
    if (sel) sel.onchange = e => { _loginStudentId = e.target.value; };
    _loginStudentId = sel ? sel.value : '';
    document.getElementById('studentLoginBtn').onclick = doStudentLogin;
    document.getElementById('loginBackBtn').onclick = closeLoginModal;
  }
}

function closeLoginModal() {
  document.getElementById('loginOverlay').classList.remove('visible');
  _pinBuffer = '';
}

function buildTeacherLoginHTML() {
  // Build teacher list from bootstrap data if available; else generic
  let options = '<option value="">— Select Teacher —</option>';
  if (window._bootstrapTeachers && window._bootstrapTeachers.length) {
    window._bootstrapTeachers.forEach(t => {
      options += `<option value="${esc(t.id)}">${esc(t.name)} (${esc(t.code)})</option>`;
    });
  }
  return `
    <span class="login-box-icon">🎓</span>
    <h2>Teacher Portal</h2>
    <p class="login-sub">Enter your credentials to mark attendance</p>
    <div class="login-field">
      <label>Select Your Name</label>
      <select id="teacherLoginSelect">${options}</select>
    </div>
    <div class="login-field">
      <label>Teacher PIN</label>
      <input type="password" id="teacherPinInput" placeholder="Enter your PIN (default: 1111)" maxlength="20" autocomplete="off" />
    </div>
    <div class="login-error" id="loginError"></div>
    <button class="btn-login" id="teacherLoginBtn">🎓 Enter Teacher Portal</button>
    <button class="btn-login-back" id="loginBackBtn">← Back to Portal Selection</button>
  `;
}

function buildAdminLoginHTML() {
  return `
    <span class="login-box-icon">⚙️</span>
    <h2>Admin Panel</h2>
    <p class="login-sub">Enter Admin PIN to access salary, fees & setup</p>
    <div class="login-field">
      <label>Admin PIN</label>
    </div>
    <div class="pin-dots" id="adminPinDots">
      <div class="pin-dot" data-i="0"></div>
      <div class="pin-dot" data-i="1"></div>
      <div class="pin-dot" data-i="2"></div>
      <div class="pin-dot" data-i="3"></div>
    </div>
    <input type="hidden" id="adminPinInput" />
    <div class="pin-pad" id="adminPinPad">
      ${[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(k =>
        k === '' ? `<div></div>` :
        `<button class="pin-key${k==='⌫'?' del':''}" data-key="${k}">${k}</button>`
      ).join('')}
    </div>
    <div class="login-error" id="loginError"></div>
    <button class="btn-login" id="adminLoginBtn">⚙️ Unlock Admin Panel</button>
    <button class="btn-login-back" id="loginBackBtn">← Back to Portal Selection</button>
  `;
}

function buildStudentLoginHTML() {
  let options = '<option value="">— Select Your Name —</option>';
  if (window._bootstrapStudents && window._bootstrapStudents.length) {
    window._bootstrapStudents.forEach(s => {
      options += `<option value="${esc(s.id)}">${esc(s.name)} (${esc(s.rollNo)})</option>`;
    });
  }
  return `
    <span class="login-box-icon">📚</span>
    <h2>Student Portal</h2>
    <p class="login-sub">Select your name to view your attendance record</p>
    <div class="login-field">
      <label>Your Name / Roll Number</label>
      <select id="studentLoginSelect">${options}</select>
    </div>
    <div class="login-error" id="loginError"></div>
    <button class="btn-login" id="studentLoginBtn" style="background:linear-gradient(135deg,#63b3ed,#2b6cb0);color:#fff;">📚 View My Attendance</button>
    <button class="btn-login-back" id="loginBackBtn">← Back to Portal Selection</button>
  `;
}

function wirePinPad(inputId, dotsId) {
  document.getElementById('adminPinPad').addEventListener('click', e => {
    const btn = e.target.closest('[data-key]');
    if (!btn) return;
    const key = btn.dataset.key;
    if (key === '⌫') {
      _pinBuffer = _pinBuffer.slice(0, -1);
    } else if (_pinBuffer.length < 4) {
      _pinBuffer += key;
    }
    updatePinDots();
    document.getElementById(inputId).value = _pinBuffer;
  });
}

function updatePinDots() {
  const dots = document.querySelectorAll('#adminPinDots .pin-dot');
  dots.forEach((d, i) => d.classList.toggle('filled', i < _pinBuffer.length));
}

async function doTeacherLogin() {
  const sel = document.getElementById('teacherLoginSelect');
  const pinEl = document.getElementById('teacherPinInput');
  const errEl = document.getElementById('loginError');
  const teacherId = sel ? sel.value : '';
  const pin = pinEl ? pinEl.value.trim() : '';
  if (!teacherId) { errEl.textContent = 'Please select your name.'; return; }
  if (!pin) { errEl.textContent = 'Please enter your PIN.'; return; }
  try {
    const res = await fetch('/api/auth/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role: 'teacher', pin, teacherId })
    });
    const data = await res.json();
    if (!res.ok || !data.verified) {
      errEl.textContent = data.error || 'Invalid PIN. Please try again.';
      return;
    }
    // Success
    state.role = 'teacher';
    state.adminUnlocked = false;
    state.activeTeacherId = teacherId;
    state.activeTab = 'mark';
    closeLoginModal();
    enterPortal('teacher', teacherId);
  } catch (e) {
    errEl.textContent = 'Server error. Please try again.';
  }
}

async function doAdminLogin() {
  const pin = _pinBuffer;
  const errEl = document.getElementById('loginError');
  if (pin.length < 4) { errEl.textContent = 'Enter 4-digit PIN.'; return; }
  try {
    const res = await fetch('/api/auth/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role: 'admin', pin })
    });
    const data = await res.json();
    if (!res.ok || !data.verified) {
      errEl.textContent = data.error || 'Wrong PIN. Try again.';
      _pinBuffer = '';
      updatePinDots();
      return;
    }
    state.role = 'admin';
    state.adminUnlocked = true;
    state.activeTab = 'admin';
    closeLoginModal();
    enterPortal('admin', null);
  } catch (e) {
    errEl.textContent = 'Server error. Please try again.';
  }
}

function doStudentLogin() {
  const sel = document.getElementById('studentLoginSelect');
  const errEl = document.getElementById('loginError');
  const studentId = sel ? sel.value : '';
  if (!studentId) { errEl.textContent = 'Please select your name.'; return; }
  state.role = 'student';
  state.adminUnlocked = false;
  state.activeStudentId = studentId;
  state.activeTab = 'student_portal';
  closeLoginModal();
  enterPortal('student', studentId);
}

function enterPortal(role, entityId) {
  // Hide landing, show app shell
  document.getElementById('portalLanding').classList.add('hidden');
  const shell = document.getElementById('appShell');
  shell.style.display = '';
  // Apply body class for CSS role gates
  document.body.className = `role-${role}`;
  // Show session badge
  renderSessionBadge(role, entityId);
  // Load data
  loadBootstrap(false);
}

function renderSessionBadge(role, entityId) {
  const el = document.getElementById('sessionBadge');
  let label = '', dotClass = '', icon = '';
  if (role === 'teacher') {
    const t = window._bootstrapTeachers?.find(x => x.id === entityId);
    label = t ? `${t.name}` : 'Teacher';
    dotClass = 'dot-green'; icon = '🎓';
  } else if (role === 'admin') {
    label = 'Admin Panel'; dotClass = 'dot-gold2'; icon = '⚙️';
  } else {
    const s = window._bootstrapStudents?.find(x => x.id === entityId);
    label = s ? `${s.name}` : 'Student';
    dotClass = 'dot-blue'; icon = '📚';
  }
  el.innerHTML = `
    <div class="session-badge" title="Logged in as ${esc(label)}">
      <span class="session-dot ${dotClass}"></span>
      ${icon} <strong>${esc(label)}</strong>
    </div>`;
}

function doLogout() {
  // Reset state and go back to landing
  state.role = 'teacher';
  state.adminUnlocked = false;
  state.activeTab = 'overview';
  state.data = null;
  document.body.className = '';
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('portalLanding').classList.remove('hidden');
  document.getElementById('mainStage').innerHTML = `
    <div class="loading-card glass-panel">
      <div class="spinner-gold"></div>
      <p>Loading CLASS RECORDS institutional ledger…</p>
    </div>`;
}

// Pre-load teacher/student lists for login dropdowns (before entering portal)
async function preloadEntityLists() {
  try {
    const data = await fetch('/api/bootstrap?month=2026-11').then(r => r.json());
    window._bootstrapTeachers = data.teachers || [];
    window._bootstrapStudents = data.students || [];
  } catch(e) {
    window._bootstrapTeachers = [];
    window._bootstrapStudents = [];
  }
}

/* ════════════════════════════════════════════════════════
   END OF PORTAL AUTH SYSTEM
════════════════════════════════════════════════════════ */

const state = {
  role: "teacher", // 'teacher' | 'admin' | 'student'
  adminUnlocked: false,
  activeTab: "overview", // 'overview' | 'mark' | 'register' | 'payroll' | 'fees' | 'admin' | 'student_portal'
  adminSubTab: "subjects", // 'subjects' | 'teachers' | 'students' | 'settings'
  month: "2026-11",
  activeTeacherId: "",
  activeStudentId: "",
  markSubjectId: "",
  markDate: "2026-11-26",
  markSessionId: "",
  draftMarks: {}, // { studentId: 'present' | 'absent' | 'leave' }
  draftTopic: "",
  registerSubjectId: "all",
  registerFilter: "all", // 'all' | 'low' | 'fees_left'
  registerSearch: "",
  feesFilter: "left", // 'left' | 'overdue' | 'all' | 'paid'
  feesSearch: "",
  simTeacherId: "",
  simHolidays: 6,
  data: null,
};

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function currencySymbol() {
  return state.data?.settings?.currency || "₹";
}

function fmtMoney(num) {
  const n = Number(num || 0);
  const sym = currencySymbol();
  const formatted = Number.isInteger(n)
    ? n.toLocaleString("en-IN")
    : n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${sym}${formatted}`;
}

function showToast(message, type = "info") {
  const stack = document.getElementById("toastStack");
  const el = document.createElement("div");
  el.className = `toast ${type === "error" ? "toast-error" : type === "success" ? "toast-success" : ""}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.remove();
  }, 3800);
}

async function apiFetch(url, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    "x-role": state.role,
    ...(options.headers || {}),
  };
  const res = await fetch(url, { ...options, headers });
  const isJson = (res.headers.get("content-type") || "").includes("application/json");
  const payload = isJson ? await res.json() : null;
  if (!res.ok) {
    throw new Error(payload?.error || `Request failed (${res.status})`);
  }
  return payload;
}

function openModal(title, bodyHtml) {
  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalBody").innerHTML = bodyHtml;
  document.getElementById("modalBackdrop").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("modalBackdrop").classList.add("hidden");
  document.getElementById("modalBody").innerHTML = "";
}

function computeClientStats(records, leaveCreditWeight) {
  let presentCount = 0;
  let absentCount = 0;
  let leaveCount = 0;
  for (const r of records) {
    if (r.status === "present") presentCount += 1;
    else if (r.status === "absent") absentCount += 1;
    else if (r.status === "leave") leaveCount += 1;
  }
  const totalClasses = presentCount + absentCount + leaveCount;
  const isExcluded = String(leaveCreditWeight) === "exclude";
  const w = isExcluded ? 0 : Number(leaveCreditWeight || 0.5);
  const effectiveAttended = isExcluded
    ? presentCount
    : Math.round((presentCount + leaveCount * w) * 100) / 100;
  const effectiveTotal = isExcluded ? presentCount + absentCount : totalClasses;
  const percentage =
    effectiveTotal > 0 ? Math.round((effectiveAttended / effectiveTotal) * 1000) / 10 : null;
  const attendedLabel = Number.isInteger(effectiveAttended)
    ? String(effectiveAttended)
    : String(effectiveAttended);

  return {
    presentCount,
    absentCount,
    leaveCount,
    totalClasses,
    ratio: `${attendedLabel}/${effectiveTotal}`,
    percentage,
  };
}

function getMonthDayWeekday(monthStr, day) {
  const [y, m] = monthStr.split("-").map(Number);
  const d = new Date(y, m - 1, day);
  return {
    label: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"][d.getDay()],
    isSunday: d.getDay() === 0,
  };
}

function getSubjectSessions(subjectId) {
  if (!state.data) return [];
  return state.data.sessions.filter((s) => s.subjectId === subjectId);
}

function getEnrolledStudents(subjectId) {
  if (!state.data) return [];
  return state.data.students.filter((st) => st.subjectIds.includes(subjectId));
}

function syncDraftFromSession() {
  if (!state.data) return;
  const sessions = state.data.sessions;
  const subSessions = sessions.filter(
    (s) => s.subjectId === state.markSubjectId && s.sessionDate === state.markDate
  );

  if (subSessions.length > 0) {
    const exists = subSessions.find((s) => s.id === state.markSessionId);
    if (!exists) {
      state.markSessionId = subSessions[subSessions.length - 1].id;
    }
  } else {
    state.markSessionId = "";
  }

  const activeSession = sessions.find((s) => s.id === state.markSessionId);
  state.draftTopic = activeSession ? activeSession.topic : "";

  const marks = {};
  const enrolled = getEnrolledStudents(state.markSubjectId);
  for (const st of enrolled) {
    const existing = activeSession
      ? state.data.studentAttendance.find(
          (a) => a.sessionId === activeSession.id && a.studentId === st.id
        )
      : null;
    marks[st.id] = existing ? existing.status : "present";
  }
  state.draftMarks = marks;
}

async function loadBootstrap(keepSelection = true) {
  try {
    const data = await apiFetch(`/api/bootstrap?month=${encodeURIComponent(state.month)}`);
    state.data = data;

    if (!keepSelection || !data.teachers.some((t) => t.id === state.activeTeacherId)) {
      state.activeTeacherId = data.teachers[0]?.id || "";
    }
    if (!keepSelection || !data.students.some((s) => s.id === state.activeStudentId)) {
      state.activeStudentId = data.students[0]?.id || "";
    }
    if (!keepSelection || !data.subjects.some((s) => s.id === state.markSubjectId)) {
      state.markSubjectId = data.subjects[0]?.id || "";
    }
    if (!keepSelection || !data.teachers.some((t) => t.id === state.simTeacherId)) {
      state.simTeacherId = data.teachers[1]?.id || data.teachers[0]?.id || "";
    }

    syncDraftFromSession();
    renderAll();
  } catch (err) {
    showToast(err.message, "error");
  }
}

function promptRoleSwitch(targetRole) {
  if (targetRole === state.role) return;

  if (targetRole === "admin" && !state.adminUnlocked) {
    openModal(
      "Unlock Admin Panel",
      `
      <p class="card-subtitle" style="margin-bottom: 14px;">
        Subject &amp; Class creation, Teacher payroll deductions, and Student fee records are restricted to <strong>Admin Panel</strong>.
      </p>
      <form id="pinVerifyForm" style="display:flex;flex-direction:column;gap:12px;">
        <div class="field-group">
          <label class="field-label">Admin Passcode</label>
          <input type="password" id="pinInput" value="1234" placeholder="Enter Admin PIN" required />
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;">
          <span class="badge-pill badge-gold">Default College Demo PIN: 1234</span>
          <div style="display:flex;gap:8px;">
            <button type="button" class="btn-subtle" id="cancelPinBtn">Cancel</button>
            <button type="submit" class="btn-gold">Unlock Admin</button>
          </div>
        </div>
      </form>
      `
    );
    document.getElementById("cancelPinBtn").onclick = closeModal;
    document.getElementById("pinVerifyForm").onsubmit = async (e) => {
      e.preventDefault();
      const pin = document.getElementById("pinInput").value.trim();
      try {
        await apiFetch("/api/auth/verify", {
          method: "POST",
          body: JSON.stringify({ role: "admin", pin }),
        });
        state.adminUnlocked = true;
        state.role = "admin";
        if (state.activeTab === "mark") state.activeTab = "admin";
        closeModal();
        showToast("Admin Panel unlocked.", "success");
        renderAll();
      } catch (err) {
        showToast(err.message, "error");
      }
    };
    return;
  }

  state.role = targetRole;
  if (targetRole === "teacher" && state.activeTab === "admin") state.activeTab = "mark";
  if (targetRole === "student") state.activeTab = "student_portal";
  if (targetRole === "admin" && state.activeTab === "mark") state.activeTab = "admin";
  renderAll();
}

function renderAll() {
  if (!state.data) return;

  // Update header banner
  const bannerEl = document.getElementById("institutionBanner");
  if (bannerEl) {
    const inst = state.data.settings.institutionName || "Class Records";
    const dept = state.data.settings.departmentBanner || "";
    bannerEl.textContent = dept ? `${inst} • ${dept}` : inst;
  }

  // Ensure activeTab is valid for this role
  if (state.role === 'teacher' && !['overview','mark','register'].includes(state.activeTab)) {
    state.activeTab = 'mark';
  }
  if (state.role === 'admin' && !['overview','payroll','fees','admin','register'].includes(state.activeTab)) {
    state.activeTab = 'admin';
  }
  if (state.role === 'student' && !['overview','student_portal'].includes(state.activeTab)) {
    state.activeTab = 'student_portal';
  }

  // Update session badge with live data
  window._bootstrapTeachers = state.data.teachers || [];
  window._bootstrapStudents = state.data.students || [];
  renderSessionBadge(state.role, state.role === 'teacher' ? state.activeTeacherId : state.activeStudentId);

  renderNav();
  renderRoleRibbon();
  renderStage();
}

function renderNav() {
  const nav = document.getElementById("mainNav");

  // Define tabs visible per role
  let tabs = [];
  if (state.role === "teacher") {
    tabs = [
      { id: "overview",  label: "📊 Overview" },
      { id: "mark",      label: "✅ Mark Attendance" },
      { id: "register",  label: "📅 1-Year / Monthly Register" },
    ];
  } else if (state.role === "admin") {
    tabs = [
      { id: "overview",  label: "📊 Overview" },
      { id: "payroll",   label: "💰 Teacher Salary & Holidays" },
      { id: "fees",      label: "🧾 Student Fees Left" },
      { id: "admin",     label: "⚙️ Admin Panel" },
      { id: "register",  label: "📅 1-Year / Monthly Register" },
    ];
  } else {
    // student — only their own portal + overview
    tabs = [
      { id: "overview",       label: "📊 Overview" },
      { id: "student_portal", label: "📚 1-Year Academic Attendance" },
    ];
  }

  nav.innerHTML = tabs
    .map((t) => {
      const activeClass = state.activeTab === t.id ? "active" : "";
      return `
        <button type="button" class="nav-tab ${activeClass}" data-tab="${t.id}">
          <span>${esc(t.label)}</span>
        </button>
      `;
    })
    .join("");

  nav.querySelectorAll(".nav-tab").forEach((btn) => {
    btn.onclick = () => {
      state.activeTab = btn.dataset.tab;
      renderAll();
    };
  });
}

function renderRoleRibbon() {
  const ribbon = document.getElementById("roleRibbon");
  const data = state.data;
  const leaveWeight = data.settings.leaveCreditWeight || "0.5";
  const leaveDesc =
    leaveWeight === "exclude"
      ? "Leave: Neutral (Excluded)"
      : `Leave: ${leaveWeight}× credit (Less % minus than Absent)`;

  if (state.role === "teacher") {
    const teacherOptions = data.teachers
      .map(
        (t) =>
          `<option value="${esc(t.id)}" ${t.id === state.activeTeacherId ? "selected" : ""}>${esc(t.name)} (${esc(t.employeeId)})</option>`
      )
      .join("");
    ribbon.innerHTML = `
      <div class="ribbon-left">
        <span class="badge-pill badge-emerald">Teacher Desk Active</span>
        <span style="color:var(--text-silver);font-size:12.5px;">
          Only Teacher can mark student <strong>Present</strong>, <strong>Absent</strong>, or <strong>Leave</strong>.
        </span>
      </div>
      <div class="ribbon-right">
        <span class="badge-pill badge-amber">${esc(leaveDesc)}</span>
        <label style="display:flex;align-items:center;gap:7px;font-size:12px;color:var(--text-muted);">
          Acting Teacher:
          <select id="ribbonTeacherSelect">${teacherOptions}</select>
        </label>
      </div>
    `;
    document.getElementById("ribbonTeacherSelect").onchange = (e) => {
      state.activeTeacherId = e.target.value;
      renderAll();
    };
  } else if (state.role === "admin") {
    ribbon.innerHTML = `
      <div class="ribbon-left">
        <span class="badge-pill badge-gold">Admin Panel Active</span>
        <span style="color:var(--text-silver);font-size:12.5px;">
          Exclusive control to add <strong>Subject Classes</strong>, mark <strong>Teacher Holidays (&gt;4 deduction)</strong>, and collect <strong>Student Fees</strong>.
        </span>
      </div>
      <div class="ribbon-right">
        <span class="badge-pill badge-amber">${esc(leaveDesc)}</span>
        <button type="button" class="btn-subtle" id="lockAdminBtn">Lock Admin</button>
      </div>
    `;
    document.getElementById("lockAdminBtn").onclick = () => {
      state.adminUnlocked = false;
      state.role = "teacher";
      if (state.activeTab === "admin") state.activeTab = "overview";
      showToast("Admin session locked. Switched to Teacher Portal.", "info");
      renderAll();
    };
  } else {
    const stuOptions = data.students
      .map(
        (s) =>
          `<option value="${esc(s.id)}" ${s.id === state.activeStudentId ? "selected" : ""}>${esc(s.rollNo)} — ${esc(s.name)}</option>`
      )
      .join("");
    ribbon.innerHTML = `
      <div class="ribbon-left">
        <span class="badge-pill badge-sapphire">Student Read-Only Portal</span>
        <span style="color:var(--text-silver);font-size:12.5px;">
          View personal 1-month attendance ratio, percentage &amp; fee status. Marking is locked to Teachers.
        </span>
      </div>
      <div class="ribbon-right">
        <label style="display:flex;align-items:center;gap:7px;font-size:12px;color:var(--text-muted);">
          Student:
          <select id="ribbonStudentSelect">${stuOptions}</select>
        </label>
      </div>
    `;
    document.getElementById("ribbonStudentSelect").onchange = (e) => {
      state.activeStudentId = e.target.value;
      renderAll();
    };
  }
}

function renderStage() {
  const stage = document.getElementById("mainStage");
  if (state.activeTab === "overview") renderOverview(stage);
  else if (state.activeTab === "mark") renderMarkAttendance(stage);
  else if (state.activeTab === "register") renderMonthlyRegister(stage);
  else if (state.activeTab === "payroll") renderTeacherPayroll(stage);
  else if (state.activeTab === "fees") renderFeesLedger(stage);
  else if (state.activeTab === "admin") renderAdminPanel(stage);
  else if (state.activeTab === "student_portal") renderStudentPortal(stage);
}

/* ==================== 1. OVERVIEW TAB ==================== */
function renderOverview(stage) {
  const data = state.data;
  const students = data.students;
  const teachers = data.teachers;

  let totalPresent = 0;
  let totalAbsent = 0;
  let totalLeave = 0;
  let totalFeesLeft = 0;
  let studentsWithFeesLeft = 0;

  for (const st of students) {
    const s = data.studentSummaries[st.id];
    totalPresent += s.attendance.presentCount;
    totalAbsent += s.attendance.absentCount;
    totalLeave += s.attendance.leaveCount;
    if (s.fees.feesLeft > 0) {
      studentsWithFeesLeft += 1;
      totalFeesLeft += s.fees.feesLeft;
    }
  }

  const overallStats = computeClientStats(
    [
      ...Array(totalPresent).fill({ status: "present" }),
      ...Array(totalAbsent).fill({ status: "absent" }),
      ...Array(totalLeave).fill({ status: "leave" }),
    ],
    data.settings.leaveCreditWeight
  );

  let totalDeduction = 0;
  let teachersExceeded = 0;
  for (const t of teachers) {
    const p = data.teacherPayrolls[t.id];
    totalDeduction += p.deductionAmount;
    if (p.excessHolidays > 0) teachersExceeded += 1;
  }

  const feesDueList = students
    .map((st) => ({ st, fees: data.studentSummaries[st.id].fees }))
    .filter((x) => x.fees.feesLeft > 0)
    .sort((a, b) => b.fees.feesLeft - a.fees.feesLeft);

  // Example student from EC-304 (1/2 = 50% showcase)
  const ecSubject = data.subjects.find((s) => s.code === "EC-304") || data.subjects[0];
  const rohan = students.find((s) => s.rollNo === "26CS02") || students[1] || students[0];
  const rohanSubStats = ecSubject && rohan ? data.studentSummaries[rohan.id]?.bySubject?.[ecSubject.id] : null;

  stage.innerHTML = `
    <div class="kpi-grid">
      <div class="glass-panel kpi-card">
        <div class="kpi-label">1-Month Classes Conducted</div>
        <div class="kpi-value">${data.sessions.length}</div>
        <div class="kpi-meta">${data.subjects.length} active subject classes • ${esc(data.month)}</div>
      </div>

      <div class="glass-panel kpi-card">
        <div class="kpi-label">Overall Student Attendance</div>
        <div class="kpi-value" style="color:${(overallStats.percentage ?? 0) >= 75 ? "#6ee7b7" : "#fcd34d"};">
          ${overallStats.percentage !== null ? `${overallStats.percentage}%` : "0%"}
        </div>
        <div class="kpi-meta mono">
          P: ${totalPresent} • A: ${totalAbsent} • L: ${totalLeave} (${esc(overallStats.ratio)})
        </div>
      </div>

      <div class="glass-panel kpi-card">
        <div class="kpi-label">Student Fees Left Pending</div>
        <div class="kpi-value" style="color:${totalFeesLeft > 0 ? "#fcd34d" : "#6ee7b7"};">
          ${fmtMoney(totalFeesLeft)}
        </div>
        <div class="kpi-meta">${studentsWithFeesLeft} of ${students.length} students have fees left</div>
      </div>

      <div class="glass-panel kpi-card">
        <div class="kpi-label">Teacher Holiday Deductions (&gt;4)</div>
        <div class="kpi-value" style="color:${totalDeduction > 0 ? "#fda4af" : "#6ee7b7"};">
          ${fmtMoney(totalDeduction)}
        </div>
        <div class="kpi-meta">${teachersExceeded} faculty exceeded 4 free holidays</div>
      </div>
    </div>

    <div class="callout-banner">
      <div>
        <div style="font-weight:700;color:var(--gold-light);margin-bottom:3px;">
          Live Class Ratio &amp; Leave Formula (${esc(rohan ? rohan.name : "Student")} in ${esc(ecSubject ? ecSubject.code : "Subject")})
        </div>
        <div style="font-size:12.5px;color:var(--text-silver);">
          Class 1 Absent = <span class="mono">0/1 (0%)</span> → Class 2 Present = <span class="mono">1/2 (50%)</span>.
          ${rohanSubStats ? `Current ${esc(ecSubject.code)}: <strong class="mono">${esc(rohanSubStats.ratio)} (${rohanSubStats.percentage ?? 0}%)</strong>` : ""}
          • <strong>Leave</strong> applies reduced penalty (<span class="mono">${esc(data.settings.leaveCreditWeight)}×</span> credit — less % minus than Absent).
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button type="button" class="btn-gold" id="ovGoMarkBtn">
          ${state.role === "teacher" ? "Take Class Attendance" : "Open 1-Month Register"}
        </button>
        <button type="button" class="btn-ghost-gold" id="ovGoRegisterBtn">Full 1-Month Matrix</button>
      </div>
    </div>

    <div class="grid-2">
      <section class="glass-panel section-card">
        <div class="card-header">
          <div>
            <h2 class="card-title">Who's Student Fees Is Left</h2>
            <p class="card-subtitle">Students with pending college fee balances</p>
          </div>
          <button type="button" class="btn-ghost-gold" id="ovViewAllFeesBtn">Open Fee Ledger</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Roll</th>
                <th>Student</th>
                <th>Fees Left</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${
                feesDueList.length === 0
                  ? `<tr><td colspan="4" style="text-align:center;color:var(--text-muted);">All student fees fully paid!</td></tr>`
                  : feesDueList
                      .slice(0, 6)
                      .map(
                        ({ st, fees }) => `
                        <tr>
                          <td class="mono">${esc(st.rollNo)}</td>
                          <td>
                            <div style="font-weight:600;">${esc(st.name)}</div>
                            <div style="font-size:11px;color:var(--text-muted);">Due: ${esc(st.feeDueDate || "-")}</div>
                          </td>
                          <td class="mono" style="color:#fcd34d;font-weight:700;">${fmtMoney(fees.feesLeft)}</td>
                          <td>
                            <span class="badge-pill ${fees.isOverdue ? "badge-crimson" : "badge-amber"}">
                              ${fees.isOverdue ? "Overdue" : "Fees Left"}
                            </span>
                          </td>
                        </tr>
                      `
                      )
                      .join("")
              }
            </tbody>
          </table>
        </div>
      </section>

      <section class="glass-panel section-card">
        <div class="card-header">
          <div>
            <h2 class="card-title">Faculty Holiday Deduction (&gt;4 Days)</h2>
            <p class="card-subtitle">Monthly 4 free holidays allowance • ${esc(data.month)}</p>
          </div>
          <button type="button" class="btn-ghost-gold" id="ovViewPayrollBtn">1-Month Payroll</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Faculty</th>
                <th>Holidays</th>
                <th>Extra (&gt;4)</th>
                <th>Deducted</th>
                <th>Net Salary</th>
              </tr>
            </thead>
            <tbody>
              ${teachers
                .map((t) => {
                  const p = data.teacherPayrolls[t.id];
                  return `
                    <tr>
                      <td>
                        <div style="font-weight:600;">${esc(t.name)}</div>
                        <div style="font-size:11px;color:var(--text-muted);">${esc(t.employeeId)} • Base ${fmtMoney(p.monthlySalary)}</div>
                      </td>
                      <td class="mono">${p.holidaysTaken} / ${p.freeHolidaysAllowed}</td>
                      <td class="mono" style="color:${p.excessHolidays > 0 ? "#fda4af" : "#6ee7b7"};">
                        ${p.excessHolidays} d
                      </td>
                      <td class="mono" style="color:${p.deductionAmount > 0 ? "#fda4af" : "var(--text-muted)"};">
                        -${fmtMoney(p.deductionAmount)}
                      </td>
                      <td class="mono" style="font-weight:700;color:var(--gold-light);">${fmtMoney(p.netSalary)}</td>
                    </tr>
                  `;
                })
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `;

  document.getElementById("ovGoMarkBtn").onclick = () => {
    state.activeTab = state.role === "teacher" ? "mark" : "register";
    renderAll();
  };
  document.getElementById("ovGoRegisterBtn").onclick = () => {
    state.activeTab = "register";
    renderAll();
  };
  document.getElementById("ovViewAllFeesBtn").onclick = () => {
    state.activeTab = "fees";
    renderAll();
  };
  document.getElementById("ovViewPayrollBtn").onclick = () => {
    state.activeTab = "payroll";
    renderAll();
  };
}

/* ==================== 2. TEACHER MARK ATTENDANCE TAB ==================== */
function renderMarkAttendance(stage) {
  if (state.role !== "teacher") {
    stage.innerHTML = `
      <section class="glass-panel lock-banner">
        <span class="badge-pill badge-emerald">Teacher Exclusive Module</span>
        <h2 class="card-title">Only Teachers Can Mark Student Attendance</h2>
        <p class="card-subtitle" style="max-width:520px;">
          To preserve academic integrity, marking student <strong>Present</strong>, <strong>Absent</strong>, or <strong>Leave</strong> is strictly locked to authenticated <strong>Teacher</strong> access.
        </p>
        <button type="button" class="btn-gold" id="switchTeacherUnlockBtn">Switch to Teacher Portal</button>
      </section>
    `;
    document.getElementById("switchTeacherUnlockBtn").onclick = () => promptRoleSwitch("teacher");
    return;
  }

  const data = state.data;
  const subjects = data.subjects;
  if (subjects.length === 0) {
    stage.innerHTML = `
      <section class="glass-panel lock-banner">
        <h2 class="card-title">No Subject Classes Configured</h2>
        <p class="card-subtitle">Subject classes must first be added inside the Admin Panel.</p>
      </section>
    `;
    return;
  }

  const activeSubject = subjects.find((s) => s.id === state.markSubjectId) || subjects[0];
  state.markSubjectId = activeSubject.id;

  const dateSessions = data.sessions.filter(
    (s) => s.subjectId === state.markSubjectId && s.sessionDate === state.markDate
  );
  const currentSession = dateSessions.find((s) => s.id === state.markSessionId) || null;
  const enrolledStudents = getEnrolledStudents(state.markSubjectId);
  const leaveWeight = data.settings.leaveCreditWeight || "0.5";

  // Pre-existing subject sessions EXCLUDING currentSession (so live draft marks compute accurate before/after ratio!)
  const otherSubjectSessions = data.sessions.filter(
    (s) => s.subjectId === state.markSubjectId && s.id !== (currentSession?.id || "")
  );
  const otherSessionIds = new Set(otherSubjectSessions.map((s) => s.id));

  const subjectAllSessions = getSubjectSessions(state.markSubjectId);

  stage.innerHTML = `
    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h2 class="card-title">Teacher Attendance Desk</h2>
          <p class="card-subtitle">
            Take Class 1, Class 2, etc. on any date • Live ratio updates immediately (<span class="mono">0/1 → 1/2 = 50%</span>) • Subject list managed in Admin Panel only.
          </p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="button" class="btn-ghost-gold" id="createNewSessionBtn">+ Take New Class Session Today</button>
        </div>
      </div>

      <div class="mark-controls-bar">
        <div class="field-group">
          <label class="field-label">Subject Class (Admin Managed)</label>
          <select id="markSubjectSelect">
            ${subjects
              .map((s) => {
                const t = data.teachers.find((x) => x.id === s.teacherId);
                return `<option value="${esc(s.id)}" ${s.id === state.markSubjectId ? "selected" : ""}>${esc(s.code)} — ${esc(s.name)}${t ? ` (${esc(t.name)})` : ""}</option>`;
              })
              .join("")}
          </select>
        </div>

        <div class="field-group">
          <label class="field-label">Class Date</label>
          <input type="date" id="markDateInput" value="${esc(state.markDate)}" />
        </div>

        <div class="field-group">
          <label class="field-label">Class Session on Selected Date</label>
          <select id="markSessionSelect">
            ${
              dateSessions.length === 0
                ? `<option value="">No session on ${esc(state.markDate)} yet (Save creates Class 1)</option>`
                : dateSessions
                    .map(
                      (s) =>
                        `<option value="${esc(s.id)}" ${s.id === currentSession?.id ? "selected" : ""}>Class #${s.sessionNumber} — ${esc(s.topic || "Lecture")}</option>`
                    )
                    .join("")
            }
          </select>
        </div>

        <div class="field-group">
          <label class="field-label">Lecture Topic</label>
          <input type="text" id="markTopicInput" value="${esc(state.draftTopic || `Lecture ${dateSessions.length + (currentSession ? 0 : 1)}`)}" placeholder="e.g. Functions & Modules" />
        </div>
      </div>

      <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;margin-bottom:14px;">
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
          <span class="badge-pill badge-emerald">Present = +1</span>
          <span class="badge-pill badge-crimson">Absent = 0 (Full Minus)</span>
          <span class="badge-pill badge-amber">Leave = +${esc(leaveWeight === "exclude" ? "Excluded" : leaveWeight)} (Less % Minus)</span>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="button" class="btn-subtle" id="markAllPresentBtn">All Present</button>
          <button type="button" class="btn-subtle" id="markAllAbsentBtn">All Absent</button>
          ${currentSession ? `<button type="button" class="btn-danger" id="deleteSessionBtn">Delete Session</button>` : ""}
          <button type="button" class="btn-gold" id="saveAttendanceBtn">Save Class Attendance</button>
        </div>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Roll No</th>
              <th>Student Name</th>
              <th>Mark Status (Teacher Only)</th>
              <th>Prior (${otherSubjectSessions.length} cls)</th>
              <th>Live After This Class</th>
              <th>Fees Status</th>
            </tr>
          </thead>
          <tbody>
            ${enrolledStudents
              .map((st) => {
                const draft = state.draftMarks[st.id] || "present";
                const priorRows = data.studentAttendance.filter(
                  (a) => a.studentId === st.id && otherSessionIds.has(a.sessionId)
                );
                const priorStats = computeClientStats(priorRows, leaveWeight);
                const afterStats = computeClientStats([...priorRows, { status: draft }], leaveWeight);
                const fees = data.studentSummaries[st.id].fees;

                return `
                  <tr>
                    <td class="mono">${esc(st.rollNo)}</td>
                    <td>
                      <div style="font-weight:600;">${esc(st.name)}</div>
                      <div style="font-size:11px;color:var(--text-muted);">${esc(st.classGrade)}</div>
                    </td>
                    <td>
                      <div class="mark-toggle-group">
                        <button type="button" class="mark-toggle ${draft === "present" ? "active-present" : ""}" data-student="${esc(st.id)}" data-status="present">Present</button>
                        <button type="button" class="mark-toggle ${draft === "absent" ? "active-absent" : ""}" data-student="${esc(st.id)}" data-status="absent">Absent</button>
                        <button type="button" class="mark-toggle ${draft === "leave" ? "active-leave" : ""}" data-student="${esc(st.id)}" data-status="leave">Leave</button>
                      </div>
                    </td>
                    <td class="mono" style="color:var(--text-muted);">
                      ${priorStats.ratio} (${priorStats.percentage !== null ? `${priorStats.percentage}%` : "—"})
                    </td>
                    <td>
                      <span class="mono" style="font-weight:700;color:${(afterStats.percentage ?? 0) >= 75 ? "#6ee7b7" : (afterStats.percentage ?? 0) >= 50 ? "#fcd34d" : "#fda4af"};">
                        ${afterStats.ratio} → ${afterStats.percentage !== null ? `${afterStats.percentage}%` : "0%"}
                      </span>
                    </td>
                    <td>
                      ${
                        fees.feesLeft > 0
                          ? `<span class="badge-pill badge-amber">${fmtMoney(fees.feesLeft)} Left</span>`
                          : `<span class="badge-pill badge-emerald">Paid</span>`
                      }
                    </td>
                  </tr>
                `;
              })
              .join("")}
          </tbody>
        </table>
      </div>
    </section>

    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h3 class="card-title" style="font-size:19px;">Sessions Taken in ${esc(activeSubject.code)} (${esc(data.month)})</h3>
          <p class="card-subtitle">Click any session to load or edit student marks</p>
        </div>
        <span class="badge-pill badge-gold">${subjectAllSessions.length} Total Lectures</span>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;">
        ${
          subjectAllSessions.length === 0
            ? `<p style="color:var(--text-muted);margin:0;">No sessions recorded yet in ${esc(activeSubject.code)} this month. Click <strong>Save Class Attendance</strong> or <strong>+ Take New Class Session Today</strong> above to begin at 0/1 or 1/1!</p>`
            : subjectAllSessions
                .map(
                  (s) => `
                  <button type="button" class="btn-subtle ${s.id === currentSession?.id ? "active" : ""}" data-load-session="${esc(s.id)}" data-load-date="${esc(s.sessionDate)}">
                    <span class="mono">${esc(s.sessionDate)}</span> • #${s.sessionNumber}: ${esc(s.topic)}
                  </button>
                `
                )
                .join("")
        }
      </div>
    </section>
  `;

  document.getElementById("markSubjectSelect").onchange = (e) => {
    state.markSubjectId = e.target.value;
    state.markSessionId = "";
    syncDraftFromSession();
    renderStage();
  };

  document.getElementById("markDateInput").onchange = (e) => {
    state.markDate = e.target.value;
    const pickedMonth = state.markDate.slice(0, 7);
    if (pickedMonth && pickedMonth !== state.month) {
      state.month = pickedMonth;
      document.getElementById("monthPicker").value = pickedMonth;
      loadBootstrap(true);
      return;
    }
    state.markSessionId = "";
    syncDraftFromSession();
    renderStage();
  };

  document.getElementById("markSessionSelect").onchange = (e) => {
    state.markSessionId = e.target.value;
    syncDraftFromSession();
    renderStage();
  };

  document.getElementById("markTopicInput").oninput = (e) => {
    state.draftTopic = e.target.value;
  };

  stage.querySelectorAll(".mark-toggle").forEach((btn) => {
    btn.onclick = () => {
      state.draftMarks[btn.dataset.student] = btn.dataset.status;
      renderStage();
    };
  });

  document.getElementById("markAllPresentBtn").onclick = () => {
    for (const st of enrolledStudents) state.draftMarks[st.id] = "present";
    renderStage();
  };

  document.getElementById("markAllAbsentBtn").onclick = () => {
    for (const st of enrolledStudents) state.draftMarks[st.id] = "absent";
    renderStage();
  };

  document.getElementById("createNewSessionBtn").onclick = async () => {
    try {
      const records = enrolledStudents.map((st) => ({
        studentId: st.id,
        status: state.draftMarks[st.id] || "present",
      }));
      const topic =
        document.getElementById("markTopicInput").value.trim() ||
        `Class Lecture ${dateSessions.length + 1}`;
      const res = await apiFetch("/api/sessions", {
        method: "POST",
        body: JSON.stringify({
          subjectId: state.markSubjectId,
          sessionDate: state.markDate,
          teacherId: state.activeTeacherId,
          topic,
          records,
        }),
      });
      state.markSessionId = res.session.id;
      showToast(`Created Class #${res.session.sessionNumber} on ${state.markDate}!`, "success");
      await loadBootstrap(true);
    } catch (err) {
      showToast(err.message, "error");
    }
  };

  document.getElementById("saveAttendanceBtn").onclick = async () => {
    try {
      const records = enrolledStudents.map((st) => ({
        studentId: st.id,
        status: state.draftMarks[st.id] || "present",
      }));
      const topic = document.getElementById("markTopicInput").value.trim() || "Class Lecture";

      if (currentSession) {
        await apiFetch(`/api/sessions/${currentSession.id}/attendance`, {
          method: "POST",
          body: JSON.stringify({
            teacherId: state.activeTeacherId,
            topic,
            records,
          }),
        });
        showToast("Class attendance saved & ratios updated!", "success");
      } else {
        const res = await apiFetch("/api/sessions", {
          method: "POST",
          body: JSON.stringify({
            subjectId: state.markSubjectId,
            sessionDate: state.markDate,
            teacherId: state.activeTeacherId,
            topic,
            records,
          }),
        });
        state.markSessionId = res.session.id;
        showToast(`Saved Class #${res.session.sessionNumber} attendance!`, "success");
      }
      await loadBootstrap(true);
    } catch (err) {
      showToast(err.message, "error");
    }
  };

  const delBtn = document.getElementById("deleteSessionBtn");
  if (delBtn) {
    delBtn.onclick = async () => {
      if (!currentSession) return;
      try {
        await apiFetch(`/api/sessions/${currentSession.id}`, { method: "DELETE" });
        state.markSessionId = "";
        showToast("Class session removed.", "info");
        await loadBootstrap(true);
      } catch (err) {
        showToast(err.message, "error");
      }
    };
  }

  stage.querySelectorAll("[data-load-session]").forEach((btn) => {
    btn.onclick = () => {
      state.markDate = btn.dataset.loadDate;
      state.markSessionId = btn.dataset.loadSession;
      syncDraftFromSession();
      renderStage();
    };
  });
}

/* ==================== 3. FULL 1-MONTH REGISTER TAB ==================== */
function renderMonthlyRegister(stage) {
  const data = state.data;
  const daysCount = data.daysInMonth;
  const subFilter = state.registerSubjectId;
  const targetPct = Number(data.settings.minAttendanceTarget || 75);

  const filteredSessions =
    subFilter === "all"
      ? data.sessions
      : data.sessions.filter((s) => s.subjectId === subFilter);

  const sessionsByDay = {};
  for (let d = 1; d <= daysCount; d += 1) sessionsByDay[d] = [];
  for (const s of filteredSessions) {
    const dayNum = Number(s.sessionDate.split("-")[2]);
    if (sessionsByDay[dayNum]) sessionsByDay[dayNum].push(s);
  }

  const attMap = {};
  for (const a of data.studentAttendance) {
    attMap[`${a.sessionId}_${a.studentId}`] = a;
  }

  const students = data.students.filter((st) => {
    const summary = data.studentSummaries[st.id];
    const att =
      subFilter === "all"
        ? summary.attendance
        : summary.bySubject[subFilter] || { percentage: null };
    const q = state.registerSearch.trim().toLowerCase();
    if (
      q &&
      !st.name.toLowerCase().includes(q) &&
      !st.rollNo.toLowerCase().includes(q)
    ) {
      return false;
    }
    if (state.registerFilter === "low") {
      return att.percentage !== null && att.percentage < targetPct;
    }
    if (state.registerFilter === "fees_left") {
      return summary.fees.feesLeft > 0;
    }
    return true;
  });

  if (data.isAnnualView) {
    const months = data.monthsList || [];
    stage.innerHTML = `
      <section class="glass-panel section-card">
        <div class="card-header">
          <div>
            <h2 class="card-title">🌟 Full 1-Year Academic Attendance Register (Academic Year ${esc(data.academicYear || "2026")})</h2>
            <p class="card-subtitle">
              Comprehensive 12-Month Master Ledger • Shows Month-by-Month Attendance (Jan–Dec), Annual Class Ratio, Cumulative % &amp; Fees Left
            </p>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
            <button type="button" class="btn-ghost-gold" id="btnSwitchToMonth">📅 View Month Matrix</button>
            <a class="btn-ghost-gold" href="/api/export/student-attendance.csv?month=all&subjectId=${encodeURIComponent(subFilter)}">
              Export Annual CSV
            </a>
          </div>
        </div>

        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;">
          <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
            <select id="regSubjectSelect">
              <option value="all" ${subFilter === "all" ? "selected" : ""}>All Subjects Combined</option>
              ${data.subjects
                .map(
                  (s) =>
                    `<option value="${esc(s.id)}" ${subFilter === s.id ? "selected" : ""}>${esc(s.code)} — ${esc(s.name)}</option>`
                )
                .join("")}
            </select>
            <input type="text" id="regSearchInput" value="${esc(state.registerSearch)}" placeholder="Search roll or name…" />
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <button type="button" class="btn-subtle ${state.registerFilter === "all" ? "active" : ""}" data-rfilter="all">All (${data.students.length})</button>
            <button type="button" class="btn-subtle ${state.registerFilter === "low" ? "active" : ""}" data-rfilter="low">&lt; ${targetPct}% Annual Alert</button>
            <button type="button" class="btn-subtle ${state.registerFilter === "fees_left" ? "active" : ""}" data-rfilter="fees_left">Fees Left Only</button>
          </div>
        </div>

        <div class="table-wrap">
          <table class="matrix-table">
            <thead>
              <tr>
                <th class="sticky-col">Student</th>
                ${months
                  .map(
                    (m) =>
                      `<th style="min-width:65px;text-align:center;">
                        <div>${esc(m.short)}</div>
                        <div style="font-size:9px;color:var(--text-muted);">${m.year}</div>
                      </th>`
                  )
                  .join("")}
                <th style="min-width:90px;">Annual Ratio</th>
                <th style="min-width:85px;">Annual %</th>
                <th style="min-width:90px;">Fees Left</th>
              </tr>
            </thead>
            <tbody>
              ${students
                .map((st) => {
                  const annualSummary = data.annualStudentSummaries?.[st.id] || {};
                  const annualAtt =
                    subFilter === "all"
                      ? annualSummary.annual || { ratio: "0/0", percentage: null }
                      : annualSummary.bySubject?.[subFilter] || { ratio: "0/0", percentage: null };
                  const breakdown = annualSummary.monthlyBreakdown || {};
                  const fees = annualSummary.fees || { feesLeft: 0 };
                  const pctColor =
                    annualAtt.percentage === null
                      ? "var(--text-muted)"
                      : annualAtt.percentage >= targetPct
                      ? "#6ee7b7"
                      : annualAtt.percentage >= 50
                      ? "#fcd34d"
                      : "#fda4af";

                  const monthCells = months
                    .map((m) => {
                      const mAtt = breakdown[m.key] || { ratio: "0/0", percentage: null };
                      const badgeColor =
                        mAtt.percentage === null
                          ? "var(--text-muted)"
                          : mAtt.percentage >= targetPct
                          ? "#6ee7b7"
                          : mAtt.percentage >= 50
                          ? "#fcd34d"
                          : "#fda4af";
                      return `
                        <td style="text-align:center;padding:6px 4px;">
                          <div class="mono" style="font-size:11px;font-weight:600;">${esc(mAtt.ratio)}</div>
                          <div class="mono" style="font-size:10px;color:${badgeColor};font-weight:700;">
                            ${mAtt.percentage !== null ? `${mAtt.percentage}%` : "—"}
                          </div>
                        </td>
                      `;
                    })
                    .join("");

                  return `
                    <tr>
                      <td class="sticky-col">
                        <div style="font-weight:600;">${esc(st.name)}</div>
                        <div class="mono" style="font-size:11px;color:var(--text-muted);">${esc(st.rollNo)}</div>
                      </td>
                      ${monthCells}
                      <td class="mono" style="font-weight:700;font-size:13px;color:var(--gold-light);">${esc(annualAtt.ratio)}</td>
                      <td class="mono" style="font-weight:700;color:${pctColor};font-size:13px;">
                        ${annualAtt.percentage !== null ? `${annualAtt.percentage}%` : "—"}
                      </td>
                      <td class="mono" style="color:${fees.feesLeft > 0 ? "#fcd34d" : "#6ee7b7"};font-weight:600;">
                        ${fees.feesLeft > 0 ? fmtMoney(fees.feesLeft) : "Paid"}
                      </td>
                    </tr>
                  `;
                })
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;

    const switchBtn = document.getElementById("btnSwitchToMonth");
    if (switchBtn) {
      switchBtn.onclick = () => {
        const ps = document.getElementById("periodSelector");
        if (ps) ps.value = "2026-11";
        state.month = "2026-11";
        loadBootstrap(true);
      };
    }

    document.getElementById("regSubjectSelect").onchange = (e) => {
      state.registerSubjectId = e.target.value;
      renderStage();
    };
    document.getElementById("regSearchInput").oninput = (e) => {
      state.registerSearch = e.target.value;
      renderStage();
    };
    stage.querySelectorAll("[data-rfilter]").forEach((btn) => {
      btn.onclick = () => {
        state.registerFilter = btn.dataset.rfilter;
        renderStage();
      };
    });
    return;
  }

  stage.innerHTML = `
    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h2 class="card-title">Full 1-Month Student Attendance Register (${esc(data.month)})</h2>
          <p class="card-subtitle">
            Complete ${daysCount}-day calendar matrix • Shows Present, Absent, Leave, Class Ratio (<span class="mono">0/1, 1/2</span>), Total % &amp; Fees Left
          </p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
          <button type="button" class="btn-ghost-gold" id="btnSwitchToYear">🌟 View Full 1-Year Register</button>
          <a class="btn-ghost-gold" href="/api/export/student-attendance.csv?month=${encodeURIComponent(data.month)}&subjectId=${encodeURIComponent(subFilter)}">
            Export CSV
          </a>
        </div>
      </div>

      <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;">
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
          <select id="regSubjectSelect">
            <option value="all" ${subFilter === "all" ? "selected" : ""}>All Subjects Combined</option>
            ${data.subjects
              .map(
                (s) =>
                  `<option value="${esc(s.id)}" ${subFilter === s.id ? "selected" : ""}>${esc(s.code)} — ${esc(s.name)}</option>`
              )
              .join("")}
          </select>
          <input type="text" id="regSearchInput" value="${esc(state.registerSearch)}" placeholder="Search roll or name…" />
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          <button type="button" class="btn-subtle ${state.registerFilter === "all" ? "active" : ""}" data-rfilter="all">All (${data.students.length})</button>
          <button type="button" class="btn-subtle ${state.registerFilter === "low" ? "active" : ""}" data-rfilter="low">&lt; ${targetPct}% Alert</button>
          <button type="button" class="btn-subtle ${state.registerFilter === "fees_left" ? "active" : ""}" data-rfilter="fees_left">Fees Left Only</button>
        </div>
      </div>

      <div class="table-wrap">
        <table class="matrix-table">
          <thead>
            <tr>
              <th class="sticky-col">Student</th>
              ${Array.from({ length: daysCount }, (_, i) => {
                const d = i + 1;
                const wd = getMonthDayWeekday(data.month, d);
                return `<th class="${wd.isSunday ? "weekend-col" : ""}" title="${data.month}-${String(d).padStart(2, "0")}">
                  <div>${String(d).padStart(2, "0")}</div>
                  <div style="font-size:9px;color:var(--text-muted);font-weight:500;">${wd.label}</div>
                </th>`;
              }).join("")}
              <th>Present</th>
              <th>Absent</th>
              <th>Leave</th>
              <th>Ratio</th>
              <th>Total %</th>
              <th>Fees Left</th>
            </tr>
          </thead>
          <tbody>
            ${students
              .map((st) => {
                const summary = data.studentSummaries[st.id];
                const att =
                  subFilter === "all"
                    ? summary.attendance
                    : summary.bySubject[subFilter] || {
                        presentCount: 0,
                        absentCount: 0,
                        leaveCount: 0,
                        ratio: "0/0",
                        percentage: null,
                      };
                const fees = summary.fees;

                const dayCells = Array.from({ length: daysCount }, (_, i) => {
                  const d = i + 1;
                  const wd = getMonthDayWeekday(data.month, d);
                  const daySessions = sessionsByDay[d];
                  const marks = daySessions
                    .map((ses) => ({ ses, rec: attMap[`${ses.id}_${st.id}`] }))
                    .filter((x) => x.rec);

                  if (marks.length === 0) {
                    return `<td class="${wd.isSunday ? "weekend-col" : ""}"><span class="day-cell-pill st-none">·</span></td>`;
                  }
                  if (marks.length === 1) {
                    const m = marks[0];
                    const code = m.rec.status === "present" ? "P" : m.rec.status === "absent" ? "A" : "L";
                    return `
                      <td class="${wd.isSunday ? "weekend-col" : ""}">
                        <button type="button" class="day-cell-pill day-cell-btn st-${m.rec.status}"
                          data-edit-day="${d}" data-edit-stu="${esc(st.id)}"
                          title="Click to inspect${state.role === "teacher" ? " / edit" : ""}">
                          ${code}
                        </button>
                      </td>
                    `;
                  }
                  const compact = marks
                    .map((m) => (m.rec.status === "present" ? "P" : m.rec.status === "absent" ? "A" : "L"))
                    .join("");
                  const allAbsent = marks.every((m) => m.rec.status === "absent");
                  const allPresent = marks.every((m) => m.rec.status === "present");
                  const cls = allPresent ? "st-present" : allAbsent ? "st-absent" : "st-leave";
                  return `
                    <td class="${wd.isSunday ? "weekend-col" : ""}">
                      <button type="button" class="day-cell-pill day-cell-btn ${cls}"
                        data-edit-day="${d}" data-edit-stu="${esc(st.id)}"
                        title="${marks.length} classes held on day ${d}">
                        ${esc(compact)}
                      </button>
                    </td>
                  `;
                }).join("");

                const pctColor =
                  att.percentage === null
                    ? "var(--text-muted)"
                    : att.percentage >= targetPct
                    ? "#6ee7b7"
                    : att.percentage >= 50
                    ? "#fcd34d"
                    : "#fda4af";

                return `
                  <tr>
                    <td class="sticky-col">
                      <div style="font-weight:600;">${esc(st.name)}</div>
                      <div class="mono" style="font-size:11px;color:var(--text-muted);">${esc(st.rollNo)}</div>
                    </td>
                    ${dayCells}
                    <td class="mono" style="color:#6ee7b7;font-weight:700;">${att.presentCount}</td>
                    <td class="mono" style="color:#fda4af;font-weight:700;">${att.absentCount}</td>
                    <td class="mono" style="color:#fcd34d;font-weight:700;">${att.leaveCount}</td>
                    <td class="mono" style="font-weight:700;">${esc(att.ratio)}</td>
                    <td class="mono" style="font-weight:700;color:${pctColor};">
                      ${att.percentage !== null ? `${att.percentage}%` : "—"}
                    </td>
                    <td class="mono" style="color:${fees.feesLeft > 0 ? "#fcd34d" : "#6ee7b7"};font-weight:600;">
                      ${fees.feesLeft > 0 ? fmtMoney(fees.feesLeft) : "Paid"}
                    </td>
                  </tr>
                `;
              })
              .join("")}
          </tbody>
        </table>
      </div>
    </section>
  `;

  document.getElementById("regSubjectSelect").onchange = (e) => {
    state.registerSubjectId = e.target.value;
    renderStage();
  };
  document.getElementById("regSearchInput").oninput = (e) => {
    state.registerSearch = e.target.value;
    renderStage();
  };
  stage.querySelectorAll("[data-rfilter]").forEach((btn) => {
    btn.onclick = () => {
      state.registerFilter = btn.dataset.rfilter;
      renderStage();
    };
  });

  const btnYr = document.getElementById("btnSwitchToYear");
  if (btnYr) {
    btnYr.onclick = () => {
      const ps = document.getElementById("periodSelector");
      if (ps) ps.value = "all";
      state.month = "all";
      loadBootstrap(true);
    };
  }

  stage.querySelectorAll("[data-edit-day]").forEach((btn) => {
    btn.onclick = () => {
      const dayNum = Number(btn.dataset.editDay);
      const stuId = btn.dataset.editStu;
      const student = data.students.find((s) => s.id === stuId);
      const daySessions = sessionsByDay[dayNum] || [];
      const rowsHtml = daySessions
        .map((ses) => {
          const sub = data.subjects.find((x) => x.id === ses.subjectId);
          const rec = attMap[`${ses.id}_${stuId}`];
          const cur = rec ? rec.status : "present";
          return `
            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);margin-bottom:10px;">
              <div style="font-weight:600;margin-bottom:6px;">
                ${esc(sub?.code || "")} • Class #${ses.sessionNumber} — ${esc(ses.topic)}
              </div>
              ${
                state.role === "teacher"
                  ? `
                  <div class="mark-toggle-group">
                    <button type="button" class="mark-toggle ${cur === "present" ? "active-present" : ""}" data-cell-ses="${esc(ses.id)}" data-cell-st="present">Present</button>
                    <button type="button" class="mark-toggle ${cur === "absent" ? "active-absent" : ""}" data-cell-ses="${esc(ses.id)}" data-cell-st="absent">Absent</button>
                    <button type="button" class="mark-toggle ${cur === "leave" ? "active-leave" : ""}" data-cell-ses="${esc(ses.id)}" data-cell-st="leave">Leave</button>
                  </div>
                  `
                  : `<span class="badge-pill badge-gold">Status: ${esc(cur.toUpperCase())} (Teacher Only Edit)</span>`
              }
            </div>
          `;
        })
        .join("");

      openModal(
        `${student?.name || "Student"} — ${data.month}-${String(dayNum).padStart(2, "0")}`,
        rowsHtml || "<p>No classes on this date.</p>"
      );

      document.querySelectorAll("[data-cell-ses]").forEach((mBtn) => {
        mBtn.onclick = async () => {
          try {
            await apiFetch("/api/student-attendance/cell", {
              method: "PUT",
              body: JSON.stringify({
                sessionId: mBtn.dataset.cellSes,
                studentId: stuId,
                status: mBtn.dataset.cellSt,
                teacherId: state.activeTeacherId,
              }),
            });
            closeModal();
            showToast("Attendance updated!", "success");
            await loadBootstrap(true);
          } catch (err) {
            showToast(err.message, "error");
          }
        };
      });
    };
  });
}

/* ==================== 4. TEACHER HOLIDAYS & SALARY DEDUCTION TAB ==================== */
function renderTeacherPayroll(stage) {
  const data = state.data;
  const daysCount = data.daysInMonth;
  const teachers = data.teachers;

  const tAttMap = {};
  for (const r of data.teacherAttendance) {
    tAttMap[`${r.teacherId}_${r.date}`] = r;
  }

  const simTeacher = teachers.find((t) => t.id === state.simTeacherId) || teachers[0];
  const simFree = simTeacher ? simTeacher.freeHolidaysAllowed : 4;
  const simSalary = simTeacher ? simTeacher.monthlySalary : 45000;
  const simRate =
    simTeacher?.deductionMode === "fixed"
      ? simTeacher.fixedDeductionPerDay
      : Math.round((simSalary / daysCount) * 100) / 100;
  const simExtra = Math.max(0, state.simHolidays - simFree);
  const simDeduct = Math.round(simExtra * simRate * 100) / 100;
  const simNet = Math.max(0, Math.round((simSalary - simDeduct) * 100) / 100);

  stage.innerHTML = `
    <div class="callout-banner">
      <div>
        <div style="font-weight:700;color:var(--gold-light);">
          Teacher Holiday Deduction Policy (&gt; 4 Free Holidays / Month)
        </div>
        <div style="font-size:12.5px;color:var(--text-silver);">
          Up to <strong>4 holidays</strong> per month = <strong>${fmtMoney(0)} deduction</strong>. Every holiday beyond 4 deducts 1 day's pay (<span class="mono">Monthly Salary ÷ ${daysCount} days</span> or configured fixed rate). Sundays / College Off days do not count against the 4 free holidays.
        </div>
      </div>
      <a class="btn-ghost-gold" href="/api/export/teacher-payroll.csv?month=${encodeURIComponent(data.month)}">
        Export Payroll CSV
      </a>
    </div>

    <div class="kpi-grid">
      ${teachers
        .map((t) => {
          const p = data.teacherPayrolls[t.id];
          const pct = Math.min(100, Math.round((p.holidaysTaken / Math.max(1, p.freeHolidaysAllowed)) * 100));
          const exceeded = p.excessHolidays > 0;
          return `
            <div class="glass-panel section-card" style="padding:18px;">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
                <div>
                  <div style="font-weight:700;font-size:15px;">${esc(t.name)}</div>
                  <div style="font-size:11.5px;color:var(--text-muted);">${esc(t.employeeId)} • ${esc(t.department)}</div>
                </div>
                <span class="badge-pill ${exceeded ? "badge-crimson" : "badge-emerald"}">
                  ${exceeded ? `${p.excessHolidays} Extra Holiday` : "Within 4 Free"}
                </span>
              </div>

              <div style="margin:14px 0 8px;">
                <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px;">
                  <span>Holidays Taken</span>
                  <span class="mono" style="font-weight:700;">${p.holidaysTaken} / ${p.freeHolidaysAllowed} Free</span>
                </div>
                <div class="progress-track">
                  <div class="progress-fill" style="width:${pct}%;background:${exceeded ? "var(--crimson)" : "var(--emerald)"};"></div>
                </div>
              </div>

              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;margin-top:12px;">
                <div>
                  <div style="color:var(--text-muted);">Base Salary</div>
                  <div class="mono" style="font-weight:600;">${fmtMoney(p.monthlySalary)}</div>
                </div>
                <div>
                  <div style="color:var(--text-muted);">Rate / Extra Day</div>
                  <div class="mono" style="font-weight:600;">${fmtMoney(p.perDayDeduction)}</div>
                </div>
                <div>
                  <div style="color:var(--text-muted);">Money Deducted</div>
                  <div class="mono" style="font-weight:700;color:${p.deductionAmount > 0 ? "#fda4af" : "#6ee7b7"};">
                    -${fmtMoney(p.deductionAmount)}
                  </div>
                </div>
                <div>
                  <div style="color:var(--text-muted);">Net Payable</div>
                  <div class="mono" style="font-weight:700;color:var(--gold-light);">${fmtMoney(p.netSalary)}</div>
                </div>
              </div>
            </div>
          `;
        })
        .join("")}
    </div>

    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h2 class="card-title">Full 1-Month Teacher Attendance Matrix (${esc(data.month)})</h2>
          <p class="card-subtitle">
            <strong>P</strong> = Working Present • <strong>H</strong> = Holiday (1.0) • <strong>½</strong> = Half Holiday (0.5) • <strong>OFF</strong> = Sunday / College Off
            ${state.role === "admin" ? " • Click any day cell to update teacher holiday status." : " • Switch to Admin Panel to edit teacher holidays."}
          </p>
        </div>
      </div>
      <div class="table-wrap">
        <table class="matrix-table">
          <thead>
            <tr>
              <th class="sticky-col">Faculty Member</th>
              ${Array.from({ length: daysCount }, (_, i) => {
                const d = i + 1;
                const wd = getMonthDayWeekday(data.month, d);
                return `<th class="${wd.isSunday ? "weekend-col" : ""}">
                  <div>${String(d).padStart(2, "0")}</div>
                  <div style="font-size:9px;color:var(--text-muted);">${wd.label}</div>
                </th>`;
              }).join("")}
              <th>Holidays</th>
              <th>Extra (&gt;4)</th>
              <th>Deducted</th>
            </tr>
          </thead>
          <tbody>
            ${teachers
              .map((t) => {
                const p = data.teacherPayrolls[t.id];
                const cells = Array.from({ length: daysCount }, (_, i) => {
                  const d = i + 1;
                  const dateStr = `${data.month}-${String(d).padStart(2, "0")}`;
                  const wd = getMonthDayWeekday(data.month, d);
                  const row = tAttMap[`${t.id}_${dateStr}`];
                  const st = row ? row.status : "none";
                  const label =
                    st === "present"
                      ? "P"
                      : st === "holiday"
                      ? "H"
                      : st === "half_holiday"
                      ? "½"
                      : st === "inst_off"
                      ? "OFF"
                      : "·";

                  return `
                    <td class="${wd.isSunday ? "weekend-col" : ""}">
                      <button type="button" class="day-cell-pill ${state.role === "admin" ? "day-cell-btn" : ""} st-${st}"
                        data-ta-teacher="${esc(t.id)}" data-ta-date="${esc(dateStr)}" data-ta-cur="${esc(st)}">
                        ${label}
                      </button>
                    </td>
                  `;
                }).join("");

                return `
                  <tr>
                    <td class="sticky-col">
                      <div style="font-weight:600;">${esc(t.name)}</div>
                      <div class="mono" style="font-size:11px;color:var(--text-muted);">${esc(t.employeeId)}</div>
                    </td>
                    ${cells}
                    <td class="mono" style="font-weight:700;">${p.holidaysTaken}</td>
                    <td class="mono" style="color:${p.excessHolidays > 0 ? "#fda4af" : "#6ee7b7"};font-weight:700;">${p.excessHolidays}</td>
                    <td class="mono" style="color:${p.deductionAmount > 0 ? "#fda4af" : "#6ee7b7"};font-weight:700;">-${fmtMoney(p.deductionAmount)}</td>
                  </tr>
                `;
              })
              .join("")}
          </tbody>
        </table>
      </div>
    </section>

    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h2 class="card-title">Interactive Teacher Holiday Deduction Calculator</h2>
          <p class="card-subtitle">Simulate how much money gets deducted if a teacher takes more than 4 holidays</p>
        </div>
      </div>
      <div class="form-grid" style="align-items:end;">
        <div class="field-group">
          <label class="field-label">Select Faculty</label>
          <select id="simTeacherSelect">
            ${teachers
              .map(
                (t) =>
                  `<option value="${esc(t.id)}" ${t.id === simTeacher?.id ? "selected" : ""}>${esc(t.name)} (${fmtMoney(t.monthlySalary)}/mo)</option>`
              )
              .join("")}
          </select>
        </div>
        <div class="field-group">
          <label class="field-label">Holidays Taken in Month: <strong class="mono" style="color:var(--gold-light);">${state.simHolidays} days</strong></label>
          <input type="range" id="simHolidaysRange" min="0" max="15" step="0.5" value="${state.simHolidays}" />
        </div>
      </div>
      <div class="kpi-grid" style="margin-top:14px;">
        <div class="glass-panel kpi-card" style="padding:14px;">
          <div class="kpi-label">Free Limit / Extra Days</div>
          <div class="kpi-value" style="font-size:22px;">${simFree} free / ${simExtra} extra</div>
        </div>
        <div class="glass-panel kpi-card" style="padding:14px;">
          <div class="kpi-label">Per-Day Deduction Rate</div>
          <div class="kpi-value" style="font-size:22px;">${fmtMoney(simRate)}</div>
        </div>
        <div class="glass-panel kpi-card" style="padding:14px;">
          <div class="kpi-label">Money Deducted</div>
          <div class="kpi-value" style="font-size:22px;color:${simDeduct > 0 ? "#fda4af" : "#6ee7b7"};">-${fmtMoney(simDeduct)}</div>
        </div>
        <div class="glass-panel kpi-card" style="padding:14px;">
          <div class="kpi-label">Net Salary Payable</div>
          <div class="kpi-value" style="font-size:22px;color:var(--gold-light);">${fmtMoney(simNet)}</div>
        </div>
      </div>
    </section>
  `;

  document.getElementById("simTeacherSelect").onchange = (e) => {
    state.simTeacherId = e.target.value;
    renderStage();
  };
  document.getElementById("simHolidaysRange").oninput = (e) => {
    state.simHolidays = Number(e.target.value);
    renderStage();
  };

  if (state.role === "admin") {
    stage.querySelectorAll("[data-ta-teacher]").forEach((btn) => {
      btn.onclick = () => {
        const tid = btn.dataset.taTeacher;
        const dt = btn.dataset.taDate;
        const cur = btn.dataset.taCur;
        const t = teachers.find((x) => x.id === tid);
        openModal(
          `Update Teacher Attendance • ${t?.name || ""}`,
          `
          <p class="card-subtitle" style="margin-bottom:14px;">Date: <strong class="mono">${esc(dt)}</strong> (Current: ${esc(cur)})</p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <button type="button" class="btn-subtle" data-set-ta="present">Present (Working)</button>
            <button type="button" class="btn-danger" data-set-ta="holiday">Full Holiday (1.0)</button>
            <button type="button" class="btn-ghost-gold" data-set-ta="half_holiday">Half Holiday (0.5)</button>
            <button type="button" class="btn-subtle" data-set-ta="inst_off">College Off / Sunday</button>
          </div>
          `
        );
        document.querySelectorAll("[data-set-ta]").forEach((sBtn) => {
          sBtn.onclick = async () => {
            try {
              await apiFetch("/api/teacher-attendance", {
                method: "PUT",
                body: JSON.stringify({
                  teacherId: tid,
                  date: dt,
                  status: sBtn.dataset.setTa,
                }),
              });
              closeModal();
              showToast("Teacher attendance & deduction updated.", "success");
              await loadBootstrap(true);
            } catch (err) {
              showToast(err.message, "error");
            }
          };
        });
      };
    });
  }
}

/* ==================== 5. STUDENT FEES LEFT LEDGER TAB ==================== */
function renderFeesLedger(stage) {
  const data = state.data;
  const students = data.students;

  let totalExpected = 0;
  let totalCollected = 0;
  let totalLeft = 0;
  let countLeft = 0;

  for (const st of students) {
    const f = data.studentSummaries[st.id].fees;
    totalExpected += f.totalFees;
    totalCollected += f.feesPaid;
    totalLeft += f.feesLeft;
    if (f.feesLeft > 0) countLeft += 1;
  }

  const filtered = students.filter((st) => {
    const f = data.studentSummaries[st.id].fees;
    const q = state.feesSearch.trim().toLowerCase();
    if (q && !st.name.toLowerCase().includes(q) && !st.rollNo.toLowerCase().includes(q)) {
      return false;
    }
    if (state.feesFilter === "left") return f.feesLeft > 0;
    if (state.feesFilter === "overdue") return f.isOverdue;
    if (state.feesFilter === "paid") return f.feesLeft === 0;
    return true;
  });

  stage.innerHTML = `
    <div class="kpi-grid">
      <div class="glass-panel kpi-card">
        <div class="kpi-label">Total Semester Fees</div>
        <div class="kpi-value">${fmtMoney(totalExpected)}</div>
        <div class="kpi-meta">${students.length} enrolled students</div>
      </div>
      <div class="glass-panel kpi-card">
        <div class="kpi-label">Total Collected</div>
        <div class="kpi-value" style="color:#6ee7b7;">${fmtMoney(totalCollected)}</div>
        <div class="kpi-meta">${totalExpected > 0 ? Math.round((totalCollected / totalExpected) * 100) : 0}% collected</div>
      </div>
      <div class="glass-panel kpi-card">
        <div class="kpi-label">Total Fees Left</div>
        <div class="kpi-value" style="color:${totalLeft > 0 ? "#fcd34d" : "#6ee7b7"};">${fmtMoney(totalLeft)}</div>
        <div class="kpi-meta">Remaining receivable balance</div>
      </div>
      <div class="glass-panel kpi-card">
        <div class="kpi-label">Students With Fees Left</div>
        <div class="kpi-value">${countLeft}</div>
        <div class="kpi-meta">Out of ${students.length} students</div>
      </div>
    </div>

    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h2 class="card-title">Student Fees &amp; Dues Ledger</h2>
          <p class="card-subtitle">Identify exactly who's student fees is left, inspect payment receipts, and record fee installments (Admin)</p>
        </div>
      </div>

      <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;">
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          <button type="button" class="btn-subtle ${state.feesFilter === "left" ? "active" : ""}" data-ffilter="left">Fees Left Only (${countLeft})</button>
          <button type="button" class="btn-subtle ${state.feesFilter === "overdue" ? "active" : ""}" data-ffilter="overdue">Overdue</button>
          <button type="button" class="btn-subtle ${state.feesFilter === "all" ? "active" : ""}" data-ffilter="all">All Students</button>
          <button type="button" class="btn-subtle ${state.feesFilter === "paid" ? "active" : ""}" data-ffilter="paid">Fully Paid</button>
        </div>
        <input type="text" id="feesSearchInput" value="${esc(state.feesSearch)}" placeholder="Search roll or student…" />
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Roll No</th>
              <th>Student &amp; Guardian</th>
              <th>Total Fee</th>
              <th>Paid</th>
              <th>Fees Left</th>
              <th>Due Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${
              filtered.length === 0
                ? `<tr><td colspan="8" style="text-align:center;color:var(--text-muted);">No matching student fee records.</td></tr>`
                : filtered
                    .map((st) => {
                      const f = data.studentSummaries[st.id].fees;
                      return `
                        <tr>
                          <td class="mono">${esc(st.rollNo)}</td>
                          <td>
                            <div style="font-weight:600;">${esc(st.name)}</div>
                            <div style="font-size:11px;color:var(--text-muted);">${esc(st.guardianName || "Guardian")} • ${esc(st.guardianPhone || st.phone || "-")}</div>
                          </td>
                          <td class="mono">${fmtMoney(f.totalFees)}</td>
                          <td class="mono" style="color:#6ee7b7;">${fmtMoney(f.feesPaid)}</td>
                          <td class="mono" style="font-weight:700;color:${f.feesLeft > 0 ? "#fcd34d" : "#6ee7b7"};">${fmtMoney(f.feesLeft)}</td>
                          <td class="mono">${esc(st.feeDueDate || "—")}</td>
                          <td>
                            <span class="badge-pill ${
                              f.feesLeft === 0
                                ? "badge-emerald"
                                : f.isOverdue
                                ? "badge-crimson"
                                : "badge-amber"
                            }">
                              ${f.feesLeft === 0 ? "Paid" : f.isOverdue ? "Overdue" : "Fees Left"}
                            </span>
                          </td>
                          <td>
                            <div style="display:flex;gap:6px;flex-wrap:wrap;">
                              <button type="button" class="btn-subtle" data-view-receipts="${esc(st.id)}">Receipts</button>
                              ${
                                state.role === "admin" && f.feesLeft > 0
                                  ? `<button type="button" class="btn-gold" style="padding:6px 10px;font-size:12px;" data-pay-student="${esc(st.id)}">Collect Fee</button>`
                                  : ""
                              }
                            </div>
                          </td>
                        </tr>
                      `;
                    })
                    .join("")
            }
          </tbody>
        </table>
      </div>
    </section>
  `;

  stage.querySelectorAll("[data-ffilter]").forEach((btn) => {
    btn.onclick = () => {
      state.feesFilter = btn.dataset.ffilter;
      renderStage();
    };
  });
  document.getElementById("feesSearchInput").oninput = (e) => {
    state.feesSearch = e.target.value;
    renderStage();
  };

  stage.querySelectorAll("[data-view-receipts]").forEach((btn) => {
    btn.onclick = () => {
      const st = students.find((x) => x.id === btn.dataset.viewReceipts);
      const pays = data.feePayments.filter((p) => p.studentId === st.id);
      openModal(
        `Fee Payment History • ${st.name}`,
        pays.length === 0
          ? `<p style="color:var(--text-muted);">No payments recorded yet. Balance left: <strong class="mono">${fmtMoney(data.studentSummaries[st.id].fees.feesLeft)}</strong></p>`
          : `
            <div class="table-wrap">
              <table>
                <thead><tr><th>Receipt</th><th>Date</th><th>Method</th><th>Amount</th></tr></thead>
                <tbody>
                  ${pays
                    .map(
                      (p) => `
                        <tr>
                          <td class="mono">${esc(p.receiptNo)}</td>
                          <td class="mono">${esc(p.paidOn)}</td>
                          <td>${esc(p.method)}</td>
                          <td class="mono" style="color:#6ee7b7;font-weight:700;">${fmtMoney(p.amount)}</td>
                        </tr>
                      `
                    )
                    .join("")}
                </tbody>
              </table>
            </div>
          `
      );
    };
  });

  stage.querySelectorAll("[data-pay-student]").forEach((btn) => {
    btn.onclick = () => {
      const st = students.find((x) => x.id === btn.dataset.payStudent);
      const feesLeft = data.studentSummaries[st.id].fees.feesLeft;
      openModal(
        `Record Fee Payment • ${st.name}`,
        `
        <p class="card-subtitle" style="margin-bottom:14px;">
          Roll: <strong class="mono">${esc(st.rollNo)}</strong> • Remaining Balance: <strong class="mono" style="color:#fcd34d;">${fmtMoney(feesLeft)}</strong>
        </p>
        <form id="collectFeeForm" style="display:flex;flex-direction:column;gap:12px;">
          <div class="field-group">
            <label class="field-label">Payment Amount (${esc(currencySymbol())})</label>
            <input type="number" id="payAmountInput" min="1" max="${feesLeft}" value="${feesLeft}" required />
          </div>
          <div class="form-grid">
            <div class="field-group">
              <label class="field-label">Payment Mode</label>
              <select id="payMethodSelect">
                <option value="UPI">UPI</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Card">Card</option>
                <option value="Cash">Cash</option>
              </select>
            </div>
            <div class="field-group">
              <label class="field-label">Date</label>
              <input type="date" id="payDateInput" value="2026-11-26" required />
            </div>
          </div>
          <div class="field-group">
            <label class="field-label">Note</label>
            <input type="text" id="payNoteInput" value="Semester Tuition Installment" />
          </div>
          <div style="display:flex;justify-content:flex-end;gap:8px;">
            <button type="button" class="btn-subtle" id="cancelPayBtn">Cancel</button>
            <button type="submit" class="btn-gold">Confirm &amp; Generate Receipt</button>
          </div>
        </form>
        `
      );
      document.getElementById("cancelPayBtn").onclick = closeModal;
      document.getElementById("collectFeeForm").onsubmit = async (e) => {
        e.preventDefault();
        try {
          const res = await apiFetch(`/api/students/${st.id}/payments`, {
            method: "POST",
            body: JSON.stringify({
              amount: Number(document.getElementById("payAmountInput").value),
              method: document.getElementById("payMethodSelect").value,
              paidOn: document.getElementById("payDateInput").value,
              note: document.getElementById("payNoteInput").value,
            }),
          });
          closeModal();
          showToast(`Fee recorded! Receipt ${res.receiptNo}`, "success");
          await loadBootstrap(true);
        } catch (err) {
          showToast(err.message, "error");
        }
      };
    };
  });
}

/* ==================== 6. ADMIN PANEL (SUBJECT CLASSES & RECORDS) ==================== */
function renderAdminPanel(stage) {
  if (state.role !== "admin") {
    stage.innerHTML = `
      <section class="glass-panel lock-banner">
        <span class="badge-pill badge-gold">Admin Panel Only</span>
        <h2 class="card-title">Subject Classes &amp; Institutional Setup Restricted to Admin</h2>
        <p class="card-subtitle" style="max-width:540px;">
          Adding or editing <strong>Subject Classes</strong>, managing <strong>Faculty Salaries &amp; Holiday Rules</strong>, and configuring <strong>Student Fees</strong> is strictly locked to the Admin Panel.
        </p>
        <button type="button" class="btn-gold" id="adminGateUnlockBtn">Unlock Admin Panel (PIN: 1234)</button>
      </section>
    `;
    document.getElementById("adminGateUnlockBtn").onclick = () => promptRoleSwitch("admin");
    return;
  }

  const data = state.data;
  const subTabs = [
    { id: "subjects", label: "Subject Classes (Admin Only)" },
    { id: "teachers", label: "Teachers & Payroll Setup" },
    { id: "students", label: "Students & Fee Setup" },
    { id: "settings", label: "Leave & Deduction Policy" },
  ];

  let innerHtml = "";
  if (state.adminSubTab === "subjects") {
    innerHtml = `
      <div class="grid-2">
        <section class="glass-panel section-card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Add Subject Class (Admin Panel Only)</h3>
              <p class="card-subtitle">Create a new college subject &amp; assign faculty</p>
            </div>
            <span class="badge-pill badge-gold">Admin Exclusive</span>
          </div>
          <form id="addSubjectForm" style="display:flex;flex-direction:column;gap:12px;">
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Subject Code</label>
                <input type="text" id="subCode" placeholder="e.g. CS-306" required />
              </div>
              <div class="field-group">
                <label class="field-label">Subject Name</label>
                <input type="text" id="subName" placeholder="e.g. Database Management Systems" required />
              </div>
            </div>
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Class / Semester</label>
                <input type="text" id="subClassGrade" value="B.Tech CS • Sem 3" required />
              </div>
              <div class="field-group">
                <label class="field-label">Assigned Teacher</label>
                <select id="subTeacherId">
                  <option value="">Unassigned</option>
                  ${data.teachers
                    .map((t) => `<option value="${esc(t.id)}">${esc(t.name)} (${esc(t.employeeId)})</option>`)
                    .join("")}
                </select>
              </div>
            </div>
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Schedule Note</label>
                <input type="text" id="subSchedule" placeholder="Mon, Wed, Fri • 11:00 AM" />
              </div>
              <div class="field-group">
                <label class="field-label">Accent Color</label>
                <select id="subColor">
                  <option value="#D4AF37">Champagne Gold</option>
                  <option value="#60A5FA">Royal Sapphire</option>
                  <option value="#34D399">Emerald Mint</option>
                  <option value="#A78BFA">Imperial Violet</option>
                  <option value="#F472B6">Rose Quartz</option>
                </select>
              </div>
            </div>
            <button type="submit" class="btn-gold">Add Subject Class</button>
          </form>
        </section>

        <section class="glass-panel section-card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Configured Subject Classes (${data.subjects.length})</h3>
              <p class="card-subtitle">Automatically enrolled for matching class students</p>
            </div>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Code</th><th>Subject</th><th>Faculty</th><th>Action</th></tr>
              </thead>
              <tbody>
                ${data.subjects
                  .map((s) => {
                    const t = data.teachers.find((x) => x.id === s.teacherId);
                    return `
                      <tr>
                        <td class="mono"><span style="color:${esc(s.accentColor)};font-weight:700;">${esc(s.code)}</span></td>
                        <td>
                          <div style="font-weight:600;">${esc(s.name)}</div>
                          <div style="font-size:11px;color:var(--text-muted);">${esc(s.classGrade)} • ${esc(s.scheduleNote || "Flexible")}</div>
                        </td>
                        <td>${esc(t ? t.name : "Unassigned")}</td>
                        <td>
                          <button type="button" class="btn-danger" data-del-subject="${esc(s.id)}">Remove</button>
                        </td>
                      </tr>
                    `;
                  })
                  .join("")}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    `;
  } else if (state.adminSubTab === "teachers") {
    innerHtml = `
      <div class="grid-2">
        <section class="glass-panel section-card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Add Faculty / Teacher</h3>
              <p class="card-subtitle">Configure monthly salary &amp; deduction rules after 4 holidays</p>
            </div>
          </div>
          <form id="addTeacherForm" style="display:flex;flex-direction:column;gap:12px;">
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Faculty ID</label>
                <input type="text" id="tchEmpId" placeholder="FAC-104" required />
              </div>
              <div class="field-group">
                <label class="field-label">Full Name</label>
                <input type="text" id="tchName" placeholder="Dr. Priya Nair" required />
              </div>
            </div>
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Department</label>
                <input type="text" id="tchDept" value="Computer Science" />
              </div>
              <div class="field-group">
                <label class="field-label">Monthly Salary (${esc(currencySymbol())})</label>
                <input type="number" id="tchSalary" value="45000" min="0" required />
              </div>
            </div>
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Free Holidays / Month</label>
                <input type="number" id="tchFree" value="4" min="0" max="15" required />
              </div>
              <div class="field-group">
                <label class="field-label">Deduction Mode (&gt; Free)</label>
                <select id="tchMode">
                  <option value="pro_rata">Pro-Rata (Salary ÷ Days in Month)</option>
                  <option value="fixed">Fixed Deduction per Extra Day</option>
                </select>
              </div>
              <div class="field-group">
                <label class="field-label">Fixed Rate (If Fixed Mode)</label>
                <input type="number" id="tchFixedRate" value="1500" min="0" />
              </div>
            </div>
            <button type="submit" class="btn-gold">Add Teacher Record</button>
          </form>
        </section>

        <section class="glass-panel section-card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Faculty Directory (${data.teachers.length})</h3>
              <p class="card-subtitle">Manage salaries &amp; holiday allowances</p>
            </div>
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>ID</th><th>Teacher</th><th>Salary</th><th>Free</th><th>Action</th></tr></thead>
              <tbody>
                ${data.teachers
                  .map(
                    (t) => `
                      <tr>
                        <td class="mono">${esc(t.employeeId)}</td>
                        <td>
                          <div style="font-weight:600;">${esc(t.name)}</div>
                          <div style="font-size:11px;color:var(--text-muted);">${esc(t.department)} • ${t.deductionMode === "fixed" ? `Fixed ${fmtMoney(t.fixedDeductionPerDay)}/day` : "Pro-Rata"}</div>
                        </td>
                        <td class="mono">${fmtMoney(t.monthlySalary)}</td>
                        <td class="mono">${t.freeHolidaysAllowed}</td>
                        <td><button type="button" class="btn-danger" data-del-teacher="${esc(t.id)}">Remove</button></td>
                      </tr>
                    `
                  )
                  .join("")}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    `;
  } else if (state.adminSubTab === "students") {
    innerHtml = `
      <div class="grid-2">
        <section class="glass-panel section-card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Enroll College Student</h3>
              <p class="card-subtitle">Adds student to class subjects &amp; sets semester fee balance</p>
            </div>
          </div>
          <form id="addStudentForm" style="display:flex;flex-direction:column;gap:12px;">
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Roll Number</label>
                <input type="text" id="stuRoll" placeholder="26CS11" required />
              </div>
              <div class="field-group">
                <label class="field-label">Student Full Name</label>
                <input type="text" id="stuName" placeholder="Aryan Kulkarni" required />
              </div>
            </div>
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Course / Semester</label>
                <input type="text" id="stuClassGrade" value="B.Tech CS • Sem 3" required />
              </div>
              <div class="field-group">
                <label class="field-label">Guardian Name</label>
                <input type="text" id="stuGuardian" placeholder="Suresh Kulkarni" />
              </div>
              <div class="field-group">
                <label class="field-label">Guardian Phone</label>
                <input type="text" id="stuPhone" placeholder="+91 98765 11223" />
              </div>
            </div>
            <div class="form-grid">
              <div class="field-group">
                <label class="field-label">Total Semester Fees (${esc(currencySymbol())})</label>
                <input type="number" id="stuTotalFees" value="45000" min="0" required />
              </div>
              <div class="field-group">
                <label class="field-label">Initial Paid (${esc(currencySymbol())})</label>
                <input type="number" id="stuPaidFees" value="20000" min="0" required />
              </div>
              <div class="field-group">
                <label class="field-label">Fee Due Date</label>
                <input type="date" id="stuDueDate" value="2026-11-30" />
              </div>
            </div>
            <button type="submit" class="btn-gold">Enroll Student</button>
          </form>
        </section>

        <section class="glass-panel section-card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Student Directory (${data.students.length})</h3>
              <p class="card-subtitle">Active college enrollments &amp; fees left</p>
            </div>
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>Roll</th><th>Name</th><th>Fees Left</th><th>Action</th></tr></thead>
              <tbody>
                ${data.students
                  .map((st) => {
                    const feesLeft = data.studentSummaries[st.id].fees.feesLeft;
                    return `
                      <tr>
                        <td class="mono">${esc(st.rollNo)}</td>
                        <td style="font-weight:600;">${esc(st.name)}</td>
                        <td class="mono" style="color:${feesLeft > 0 ? "#fcd34d" : "#6ee7b7"};">${fmtMoney(feesLeft)}</td>
                        <td><button type="button" class="btn-danger" data-del-student="${esc(st.id)}">Remove</button></td>
                      </tr>
                    `;
                  })
                  .join("")}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    `;
  } else {
    const s = data.settings;
    innerHtml = `
      <section class="glass-panel section-card" style="max-width:780px;">
        <div class="card-header">
          <div>
            <h3 class="card-title">Attendance, Leave &amp; Deduction Policy</h3>
            <p class="card-subtitle">Control how Leave affects percentage and default holiday limits</p>
          </div>
        </div>
        <form id="settingsForm" style="display:flex;flex-direction:column;gap:14px;">
          <div class="form-grid">
            <div class="field-group">
              <label class="field-label">College / Institution Name</label>
              <input type="text" id="setInstName" value="${esc(s.institutionName || "")}" required />
            </div>
            <div class="field-group">
              <label class="field-label">Department / Batch Subtitle</label>
              <input type="text" id="setDeptBanner" value="${esc(s.departmentBanner || "")}" />
            </div>
          </div>
          <div class="form-grid">
            <div class="field-group">
              <label class="field-label">Leave Percentage Credit ("Less % Minus")</label>
              <select id="setLeaveWeight">
                <option value="0.5" ${s.leaveCreditWeight === "0.5" ? "selected" : ""}>0.5× Credit (Half Deduction vs Absent — Recommended)</option>
                <option value="0.75" ${s.leaveCreditWeight === "0.75" ? "selected" : ""}>0.75× Credit (Quarter Deduction vs Absent)</option>
                <option value="0.25" ${s.leaveCreditWeight === "0.25" ? "selected" : ""}>0.25× Credit (75% Deduction vs Absent)</option>
                <option value="exclude" ${s.leaveCreditWeight === "exclude" ? "selected" : ""}>Exclude Leave from Total (0% Deduction)</option>
              </select>
            </div>
            <div class="field-group">
              <label class="field-label">Default Teacher Free Holidays / Month</label>
              <input type="number" id="setFreeHolidays" value="${esc(s.freeHolidaysLimit || "4")}" min="0" max="15" />
            </div>
          </div>
          <div class="form-grid">
            <div class="field-group">
              <label class="field-label">Minimum Attendance Alert (%)</label>
              <input type="number" id="setMinTarget" value="${esc(s.minAttendanceTarget || "75")}" min="0" max="100" />
            </div>
            <div class="field-group">
              <label class="field-label">Currency Symbol</label>
              <select id="setCurrency">
                <option value="₹" ${s.currency === "₹" ? "selected" : ""}>₹ (INR)</option>
                <option value="$" ${s.currency === "$" ? "selected" : ""}>$ (USD)</option>
                <option value="€" ${s.currency === "€" ? "selected" : ""}>€ (EUR)</option>
                <option value="£" ${s.currency === "£" ? "selected" : ""}>£ (GBP)</option>
              </select>
            </div>
            <div class="field-group">
              <label class="field-label">Admin Passcode</label>
              <input type="text" id="setAdminPin" value="${esc(s.adminPin || "1234")}" />
            </div>
          </div>
          <div>
            <button type="submit" class="btn-gold">Save Institutional Settings</button>
          </div>
        </form>
      </section>
    `;
  }

  stage.innerHTML = `
    <div class="subtabs">
      ${subTabs
        .map(
          (st) =>
            `<button type="button" class="btn-subtle ${state.adminSubTab === st.id ? "active" : ""}" data-admin-sub="${st.id}">${esc(st.label)}</button>`
        )
        .join("")}
    </div>
    ${innerHtml}
  `;

  stage.querySelectorAll("[data-admin-sub]").forEach((btn) => {
    btn.onclick = () => {
      state.adminSubTab = btn.dataset.adminSub;
      renderStage();
    };
  });

  if (state.adminSubTab === "subjects") {
    document.getElementById("addSubjectForm").onsubmit = async (e) => {
      e.preventDefault();
      try {
        await apiFetch("/api/subjects", {
          method: "POST",
          body: JSON.stringify({
            code: document.getElementById("subCode").value,
            name: document.getElementById("subName").value,
            classGrade: document.getElementById("subClassGrade").value,
            teacherId: document.getElementById("subTeacherId").value || null,
            scheduleNote: document.getElementById("subSchedule").value,
            accentColor: document.getElementById("subColor").value,
          }),
        });
        showToast("Subject class added in Admin Panel!", "success");
        await loadBootstrap(true);
      } catch (err) {
        showToast(err.message, "error");
      }
    };
    stage.querySelectorAll("[data-del-subject]").forEach((btn) => {
      btn.onclick = async () => {
        try {
          await apiFetch(`/api/subjects/${btn.dataset.delSubject}`, { method: "DELETE" });
          showToast("Subject class removed.", "info");
          await loadBootstrap(true);
        } catch (err) {
          showToast(err.message, "error");
        }
      };
    });
  } else if (state.adminSubTab === "teachers") {
    document.getElementById("addTeacherForm").onsubmit = async (e) => {
      e.preventDefault();
      try {
        await apiFetch("/api/teachers", {
          method: "POST",
          body: JSON.stringify({
            employeeId: document.getElementById("tchEmpId").value,
            name: document.getElementById("tchName").value,
            department: document.getElementById("tchDept").value,
            monthlySalary: Number(document.getElementById("tchSalary").value),
            freeHolidaysAllowed: Number(document.getElementById("tchFree").value),
            deductionMode: document.getElementById("tchMode").value,
            fixedDeductionPerDay: Number(document.getElementById("tchFixedRate").value),
          }),
        });
        showToast("Faculty record created!", "success");
        await loadBootstrap(true);
      } catch (err) {
        showToast(err.message, "error");
      }
    };
    stage.querySelectorAll("[data-del-teacher]").forEach((btn) => {
      btn.onclick = async () => {
        try {
          await apiFetch(`/api/teachers/${btn.dataset.delTeacher}`, { method: "DELETE" });
          showToast("Teacher removed.", "info");
          await loadBootstrap(true);
        } catch (err) {
          showToast(err.message, "error");
        }
      };
    });
  } else if (state.adminSubTab === "students") {
    document.getElementById("addStudentForm").onsubmit = async (e) => {
      e.preventDefault();
      try {
        await apiFetch("/api/students", {
          method: "POST",
          body: JSON.stringify({
            rollNo: document.getElementById("stuRoll").value,
            name: document.getElementById("stuName").value,
            classGrade: document.getElementById("stuClassGrade").value,
            guardianName: document.getElementById("stuGuardian").value,
            guardianPhone: document.getElementById("stuPhone").value,
            totalFees: Number(document.getElementById("stuTotalFees").value),
            feesPaid: Number(document.getElementById("stuPaidFees").value),
            feeDueDate: document.getElementById("stuDueDate").value,
          }),
        });
        showToast("Student enrolled!", "success");
        await loadBootstrap(true);
      } catch (err) {
        showToast(err.message, "error");
      }
    };
    stage.querySelectorAll("[data-del-student]").forEach((btn) => {
      btn.onclick = async () => {
        try {
          await apiFetch(`/api/students/${btn.dataset.delStudent}`, { method: "DELETE" });
          showToast("Student removed.", "info");
          await loadBootstrap(true);
        } catch (err) {
          showToast(err.message, "error");
        }
      };
    });
  } else {
    document.getElementById("settingsForm").onsubmit = async (e) => {
      e.preventDefault();
      try {
        await apiFetch("/api/settings", {
          method: "PUT",
          body: JSON.stringify({
            institutionName: document.getElementById("setInstName").value,
            departmentBanner: document.getElementById("setDeptBanner").value,
            leaveCreditWeight: document.getElementById("setLeaveWeight").value,
            freeHolidaysLimit: document.getElementById("setFreeHolidays").value,
            minAttendanceTarget: document.getElementById("setMinTarget").value,
            currency: document.getElementById("setCurrency").value,
            adminPin: document.getElementById("setAdminPin").value,
          }),
        });
        showToast("Institutional policies saved!", "success");
        await loadBootstrap(true);
      } catch (err) {
        showToast(err.message, "error");
      }
    };
  }
}

/* ==================== 7. STUDENT PORTAL (READ-ONLY) ==================== */
function renderStudentPortal(stage) {
  const data = state.data;
  const student = data.students.find((s) => s.id === state.activeStudentId) || data.students[0];
  if (!student) {
    stage.innerHTML = `<section class="glass-panel section-card"><p>No student records found.</p></section>`;
    return;
  }
  state.activeStudentId = student.id;
  const summary = data.studentSummaries[student.id] || {};
  const annualSummary = data.annualStudentSummaries?.[student.id] || {};
  const annualAtt = annualSummary.annual || summary.attendance || { ratio: "0/0", percentage: null, presentCount: 0, absentCount: 0, leaveCount: 0, totalClasses: 0 };
  const monthlyBreakdown = annualSummary.monthlyBreakdown || {};
  const fees = summary.fees || annualSummary.fees || { feesPaid: 0, totalFees: 45000, feesLeft: 0 };
  const targetPct = Number(data.settings.minAttendanceTarget || 75);
  const months = data.monthsList || [];

  stage.innerHTML = `
    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h2 class="card-title">${esc(student.name)} <span class="mono" style="font-size:16px;color:var(--text-muted);">(${esc(student.rollNo)})</span></h2>
          <p class="card-subtitle">${esc(student.classGrade)} • Official 1-Year Academic Attendance &amp; Fee Ledger (2026)</p>
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
          <select id="studentPortalSelect">
            ${data.students
              .map(
                (s) =>
                  `<option value="${esc(s.id)}" ${s.id === student.id ? "selected" : ""}>${esc(s.rollNo)} — ${esc(s.name)}</option>`
              )
              .join("")}
          </select>
        </div>
      </div>

      <div class="kpi-grid">
        <div class="glass-panel kpi-card">
          <div class="kpi-label">🌟 1-Year Cumulative Attendance</div>
          <div class="kpi-value" style="color:${(annualAtt.percentage ?? 0) >= targetPct ? "#6ee7b7" : "#fcd34d"};">
            ${annualAtt.percentage !== null ? `${annualAtt.percentage}%` : "—"}
          </div>
          <div class="kpi-meta mono">Annual Ratio: ${esc(annualAtt.ratio)} • Target: ${targetPct}%</div>
        </div>
        <div class="glass-panel kpi-card">
          <div class="kpi-label">Annual Attendance Counts</div>
          <div class="kpi-value" style="font-size:22px;">
            <span style="color:#6ee7b7;">${annualAtt.presentCount}P</span> /
            <span style="color:#fda4af;">${annualAtt.absentCount}A</span> /
            <span style="color:#fcd34d;">${annualAtt.leaveCount}L</span>
          </div>
          <div class="kpi-meta">${annualAtt.totalClasses} total classes held across 12 months</div>
        </div>
        <div class="glass-panel kpi-card">
          <div class="kpi-label">Fees Paid</div>
          <div class="kpi-value" style="color:#6ee7b7;">${fmtMoney(fees.feesPaid)}</div>
          <div class="kpi-meta">Out of ${fmtMoney(fees.totalFees)}</div>
        </div>
        <div class="glass-panel kpi-card">
          <div class="kpi-label">Fees Left</div>
          <div class="kpi-value" style="color:${fees.feesLeft > 0 ? "#fcd34d" : "#6ee7b7"};">${fmtMoney(fees.feesLeft)}</div>
          <div class="kpi-meta">${fees.feesLeft === 0 ? "All dues cleared" : `Due by ${esc(student.feeDueDate || "N/A")}`}</div>
        </div>
      </div>
    </section>

    <!-- 12-Month Progression Table -->
    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h3 class="card-title">📅 12-Month Academic Attendance Progression</h3>
          <p class="card-subtitle">Month-by-month breakdown of classes, presence, leave credits, and percentage</p>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Month</th>
              <th>Classes Held</th>
              <th>Present</th>
              <th>Absent</th>
              <th>Leave (0.5×)</th>
              <th>Attended Ratio</th>
              <th>Monthly %</th>
              <th>Target Status</th>
            </tr>
          </thead>
          <tbody>
            ${months
              .map((m) => {
                const mAtt = monthlyBreakdown[m.key] || {
                  presentCount: 0,
                  absentCount: 0,
                  leaveCount: 0,
                  totalClasses: 0,
                  ratio: "0/0",
                  percentage: null,
                };
                const meetsTarget = (mAtt.percentage ?? 0) >= targetPct;
                const statusBadge =
                  mAtt.totalClasses === 0
                    ? `<span class="badge-pill badge-neutral">No Classes</span>`
                    : meetsTarget
                    ? `<span class="badge-pill badge-emerald">On Track (≥${targetPct}%)</span>`
                    : `<span class="badge-pill badge-rose">Below Target</span>`;

                return `
                  <tr>
                    <td style="font-weight:700;">${esc(m.name)} ${m.year}</td>
                    <td class="mono">${mAtt.totalClasses}</td>
                    <td class="mono" style="color:#6ee7b7;">${mAtt.presentCount}</td>
                    <td class="mono" style="color:#fda4af;">${mAtt.absentCount}</td>
                    <td class="mono" style="color:#fcd34d;">${mAtt.leaveCount}</td>
                    <td class="mono" style="font-weight:700;">${esc(mAtt.ratio)}</td>
                    <td class="mono" style="font-weight:700;color:${meetsTarget ? "#6ee7b7" : "#fcd34d"};">
                      ${mAtt.percentage !== null ? `${mAtt.percentage}%` : "—"}
                    </td>
                    <td>${statusBadge}</td>
                  </tr>
                `;
              })
              .join("")}
          </tbody>
        </table>
      </div>
    </section>

    <!-- Subject-Wise Breakdown -->
    <section class="glass-panel section-card">
      <div class="card-header">
        <div>
          <h3 class="card-title">Subject-Wise 1-Year Attendance Record</h3>
          <p class="card-subtitle">Annual subject class ratios (e.g. 0/1, 1/2) and attendance percentage</p>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Code</th>
              <th>Subject Class</th>
              <th>Present</th>
              <th>Absent</th>
              <th>Leave</th>
              <th>Class Ratio</th>
              <th>Percentage</th>
            </tr>
          </thead>
          <tbody>
            ${student.subjectIds
              .map((subId) => {
                const sub = data.subjects.find((x) => x.id === subId);
                if (!sub) return "";
                const stAtt = annualSummary.bySubject?.[subId] || summary.bySubject?.[subId] || {
                  presentCount: 0,
                  absentCount: 0,
                  leaveCount: 0,
                  ratio: "0/0",
                  percentage: null,
                };
                return `
                  <tr>
                    <td class="mono" style="color:${esc(sub.accentColor)};font-weight:700;">${esc(sub.code)}</td>
                    <td style="font-weight:600;">${esc(sub.name)}</td>
                    <td class="mono" style="color:#6ee7b7;">${stAtt.presentCount}</td>
                    <td class="mono" style="color:#fda4af;">${stAtt.absentCount}</td>
                    <td class="mono" style="color:#fcd34d;">${stAtt.leaveCount}</td>
                    <td class="mono" style="font-weight:700;">${esc(stAtt.ratio)}</td>
                    <td class="mono" style="font-weight:700;color:${(stAtt.percentage ?? 100) >= targetPct ? "#6ee7b7" : "#fcd34d"};">
                      ${stAtt.percentage !== null ? `${stAtt.percentage}%` : "No classes yet"}
                    </td>
                  </tr>
                `;
              })
              .join("")}
          </tbody>
        </table>
      </div>
    </section>
  `;

  document.getElementById("studentPortalSelect").onchange = (e) => {
    state.activeStudentId = e.target.value;
    renderAll();
  };
}

/* ==================== BOOTSTRAP & EVENT WIRING ==================== */
document.addEventListener("DOMContentLoaded", () => {
  // Pre-load entity lists so login dropdowns are populated
  preloadEntityLists();

  // Period Selector (1-Year / Month)
  const periodSel = document.getElementById("periodSelector");
  if (periodSel) {
    periodSel.onchange = (e) => {
      state.month = e.target.value;
      if (state.month !== "all" && !state.markDate.startsWith(state.month)) {
        state.markDate = state.month === "2026-11" ? "2026-11-26" : `${state.month}-01`;
        state.markSessionId = "";
      }
      loadBootstrap(true);
    };
  }

  const mp = document.getElementById("monthPicker");
  if (mp) {
    mp.onchange = (e) => {
      state.month = e.target.value || "2026-11";
      if (!state.markDate.startsWith(state.month)) {
        state.markDate = state.month === "2026-11" ? "2026-11-26" : `${state.month}-01`;
        state.markSessionId = "";
      }
      loadBootstrap(true);
    };
  }

  document.getElementById("modalCloseBtn").onclick = closeModal;
  document.getElementById("modalBackdrop").onclick = (e) => {
    if (e.target.id === "modalBackdrop") closeModal();
  };
});

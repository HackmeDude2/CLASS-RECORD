# CLASS RECORDS

**Company:** THE SHIVAGROUPS OF APP  
**Developed By:** RUDRAKSH GARG  
**Stack:** Python 3 • Flask • SQLite3 • HTML5 / Luxury CSS / Vanilla JS

---

## Project Overview

**CLASS RECORDS** is a full-stack college Python application built to manage **Student Attendance**, **Faculty Attendance & Holiday Salary Deductions**, **Subject Classes**, and **Student Fee Balances** with role-based access control and full 1-month calendar reporting.

---

## Key Features & College Formulas

1. **Role-Based Access Control (RBAC)**
   - **Teacher Portal:** Exclusively authorized to start class sessions and mark students as **Present**, **Absent**, or **Leave**.
   - **Admin Panel (`PIN: 1234`):** Exclusively authorized to **add/manage Subject Classes**, manage teachers & mark teacher 1-month holidays, enroll students, collect fee payments, and configure policies.
   - **Student Portal:** Read-only view of personal 1-month attendance, subject-wise class ratios, and remaining fees.

2. **Live Class Ratio & Attendance Percentage (`0/1` → `1/2 = 50%`)**
   - Teacher takes Class 1 and marks a student **Absent** → **`0/1 (0.0%)`**.
   - Teacher takes Class 2 and marks the student **Present** → **`1/2 (50.0%)`**.
   - **Approved Leave ("Less % Minus"):** Defaults to `0.5×` attendance credit (half the penalty of an unexcused Absence) and is configurable in Admin Settings.

3. **Full 1-Month Update & CSV Export**
   - Interactive 30/31-day monthly matrix for both **Students** and **Teachers**.
   - Switch any month via the top `1-Month Period` selector and export attendance or payroll CSV reports.

4. **Teacher Holiday Salary Deduction (`> 4 Holidays`)**
   - Every faculty member receives **4 free holidays/month**.
   - Holidays taken above 4 (`excess = max(0, holidays - 4)`) automatically deduct money based on either **Pro-Rata (`Monthly Salary ÷ Days in Month`)** or a **Fixed Daily Rate**.

5. **Student Fees Left Ledger**
   - Instantly identifies **who's student fees is left**, highlights overdue balances, tracks receipts, and lets Admin record partial or full fee installments.

---

## How to Run

### Windows One-Click
Double-click `run.bat` inside the project folder.

### Command Line
```bash
pip install -r requirements.txt
python app.py
```
Then open **http://127.0.0.1:5050** in your browser.

### Run Automated Python Unit & API Tests
```bash
python -m unittest discover -s tests -v
```

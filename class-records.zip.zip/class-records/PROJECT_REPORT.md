# CLASS RECORDS — College Python Project Report

- **Project Title:** CLASS RECORDS (Academic Attendance, Payroll & Fee Management System)
- **Company Name:** THE SHIVAGROUPS OF APP
- **Developed By:** RUDRAKSH GARG
- **Technology Stack:** Python 3.14, Flask 3.0.0, SQLite3 (`sqlite3`), HTML5, CSS3, Vanilla JavaScript

---

## 1. Code to Run

### Option A: Windows One-Click Launcher
Double-click [`run.bat`](run.bat) in the project folder:
```bat
@echo off
cd /d "%~dp0"
echo ========================================================
echo   CLASS RECORDS - THE SHIVAGROUPS OF APP
echo   Developed by RUDRAKSH GARG
echo ========================================================
start "" http://127.0.0.1:5050
python app.py
pause
```

### Option B: Command Line (PowerShell / Terminal)
```powershell
cd "C:\Users\Rudraksh Garg\.gemini\antigravity\scratch\class-records"
pip install -r requirements.txt
python app.py
```
Then open **http://127.0.0.1:5050** in your web browser.

### Run Automated Python Unit & API Tests
```powershell
cd "C:\Users\Rudraksh Garg\.gemini\antigravity\scratch\class-records"
python -m unittest discover -s tests -v
```

---

## 2. Introduction

**CLASS RECORDS** is a full-stack college Python web application developed to digitize and automate daily academic attendance, monthly registers, faculty holiday salary deductions, and student fee tracking inside a single role-secured platform.

Traditional paper registers make it slow to recalculate live attendance percentages across multiple lectures per day, track approved leave penalties fairly, monitor pending student tuition fees, and compute teacher salary deductions when monthly holidays exceed institutional allowances. **CLASS RECORDS** solves these challenges using a Python + Flask REST API backed by a relational SQLite3 database (`class_records.db`) and a luxury dark obsidian and champagne-gold web interface.

### Key Objectives & Implemented Rules
1. **Role-Based Access Control (RBAC):**
   - **Teacher Portal:** Exclusively authorized to start class sessions and mark students as **Present**, **Absent**, or **Leave**.
   - **Admin Panel (`PIN: 1234`):** Exclusively authorized to add/manage **Subject Classes**, mark **1-month Teacher Holidays**, configure leave/deduction policies, enroll students, and collect student fee installments.
   - **Student Portal:** Read-only personal view of 1-month attendance, subject-wise ratios, and fee dues.
2. **Live Attendance Ratio & Percentage Calculation (`0/1` → `1/2 = 50%`):**
   - When a teacher takes Class 1 and marks a student **Absent**, the ratio displays **`0/1` (`0.0%`)**.
   - When Class 2 is taken and the student is **Present**, the ratio updates live to **`1/2` (`50.0%`)**.
   - **Approved Leave ("Less % Minus"):** Uses a configurable reduced penalty credit (`0.5×` by default) so an approved leave deducts half as much percentage as an unexcused absence.
3. **Full 1-Month Update:**
   - Complete 30/31-day monthly matrix views for both students and teachers for any selected `YYYY-MM` period, with CSV export support.
4. **Teacher Holiday Salary Deduction (`> 4` Holidays):**
   - Faculty members receive **4 free holidays per month**. Any holiday beyond 4 automatically triggers a deduction calculated via either **Pro-Rata (`Monthly Salary ÷ Days in Month`)** or a **Fixed Daily Rate**.
5. **Student Fees Left Ledger:**
   - Highlights students whose fees are remaining, tracks overdue due dates, records partial/full installments, and generates payment receipts.

---

## 3. Source Code

### 3.1 `backend/calculations.py`
```python
"""Pure Python calculation engine for CLASS RECORDS.

Handles:
1. Student attendance ratio & percentage (e.g. 0/1 -> 0%, 1/2 -> 50%).
2. Leave penalty weighting ("less percentage minus when student doesn't come").
3. Teacher 1-month holiday counting & salary deduction on > 4 holidays.
4. Student college fee balance & overdue status.
"""

from __future__ import annotations

import calendar
from typing import Any


def get_days_in_month(month_str: str) -> int:
    """Return number of calendar days for a YYYY-MM string."""
    try:
        year_s, mon_s = month_str.split("-")
        year, mon = int(year_s), int(mon_s)
        return calendar.monthrange(year, mon)[1]
    except (ValueError, AttributeError):
        return 30


def calculate_student_attendance(
    records: list[dict[str, Any]], leave_credit_weight: str = "0.5"
) -> dict[str, Any]:
    """Calculate present, absent, leave counts, effective ratio, and percentage.

    Example:
      - 1 class held, student marked Absent  -> 0/1 (0.0%)
      - 2nd class held, student marked Present -> 1/2 (50.0%)
      - Approved Leave applies reduced minus via `leave_credit_weight` (default 0.5)
    """
    present_count = 0
    absent_count = 0
    leave_count = 0

    for row in records:
        status = row.get("status")
        if status == "present":
            present_count += 1
        elif status == "absent":
            absent_count += 1
        elif status == "leave":
            leave_count += 1

    total_classes = present_count + absent_count + leave_count
    is_excluded = str(leave_credit_weight) == "exclude"

    if is_excluded:
        effective_attended = float(present_count)
        effective_total = present_count + absent_count
    else:
        try:
            weight = float(leave_credit_weight)
        except (TypeError, ValueError):
            weight = 0.5
        effective_attended = round(present_count + (leave_count * weight), 2)
        effective_total = total_classes

    percentage = (
        round((effective_attended / effective_total) * 100.0, 1)
        if effective_total > 0
        else None
    )

    if effective_attended.is_integer():
        attended_label = str(int(effective_attended))
    else:
        attended_label = f"{effective_attended:.2f}".rstrip("0").rstrip(".")

    return {
        "presentCount": present_count,
        "absentCount": absent_count,
        "leaveCount": leave_count,
        "totalClasses": total_classes,
        "effectiveAttended": effective_attended,
        "effectiveTotal": effective_total,
        "ratio": f"{attended_label}/{effective_total}",
        "rawRatio": f"{present_count}/{total_classes}",
        "percentage": percentage,
    }


def calculate_teacher_payroll(
    teacher: dict[str, Any],
    month_str: str,
    attendance_rows: list[dict[str, Any]],
    default_free_limit: int = 4,
) -> dict[str, Any]:
    """Calculate 1-month teacher attendance and deduction for > 4 holidays."""
    days_in_month = get_days_in_month(month_str)
    present_days = 0
    full_holidays = 0
    half_holidays = 0
    inst_off_days = 0

    for row in attendance_rows:
        status = row.get("status")
        if status == "present":
            present_days += 1
        elif status == "holiday":
            full_holidays += 1
        elif status == "half_holiday":
            half_holidays += 1
        elif status == "inst_off":
            inst_off_days += 1

    holidays_taken = round(full_holidays + (half_holidays * 0.5), 2)
    free_limit = int(
        teacher.get("freeHolidaysAllowed")
        if teacher.get("freeHolidaysAllowed") is not None
        else default_free_limit
    )
    excess_holidays = round(max(0.0, holidays_taken - free_limit), 2)

    monthly_salary = float(teacher.get("monthlySalary") or 0.0)
    deduction_mode = teacher.get("deductionMode") or "pro_rata"

    if deduction_mode == "fixed":
        per_day_deduction = round(float(teacher.get("fixedDeductionPerDay") or 0.0), 2)
    else:
        per_day_deduction = round(monthly_salary / days_in_month, 2)

    deduction_amount = round(excess_holidays * per_day_deduction, 2)
    net_salary = round(max(0.0, monthly_salary - deduction_amount), 2)

    return {
        "daysInMonth": days_in_month,
        "presentDays": present_days,
        "fullHolidays": full_holidays,
        "halfHolidays": half_holidays,
        "instOffDays": inst_off_days,
        "holidaysTaken": holidays_taken,
        "freeHolidaysAllowed": free_limit,
        "excessHolidays": excess_holidays,
        "perDayDeduction": per_day_deduction,
        "deductionAmount": deduction_amount,
        "monthlySalary": round(monthly_salary, 2),
        "netSalary": net_salary,
    }


def calculate_student_fees(student: dict[str, Any], today_iso: str) -> dict[str, Any]:
    """Calculate total fees, paid amount, remaining fees left, and overdue status."""
    total_fees = round(float(student.get("totalFees") or 0.0), 2)
    fees_paid = round(float(student.get("feesPaid") or 0.0), 2)
    fees_left = round(max(0.0, total_fees - fees_paid), 2)

    if fees_left == 0:
        status = "paid"
    elif fees_paid > 0:
        status = "partial"
    else:
        status = "unpaid"

    due_date = str(student.get("feeDueDate") or "")
    is_overdue = bool(fees_left > 0 and due_date and due_date < today_iso)

    return {
        "totalFees": total_fees,
        "feesPaid": fees_paid,
        "feesLeft": fees_left,
        "status": status,
        "isOverdue": is_overdue,
    }
```

### 3.2 `app.py` (Flask Server & Role-Protected REST API)
See full source in [`app.py`](app.py) (877 lines), [`backend/database.py`](backend/database.py) (606 lines), [`tests/test_class_records.py`](tests/test_class_records.py) (212 lines), and frontend UI files [`static/index.html`](static/index.html), [`static/css/luxury.css`](static/css/luxury.css), and [`static/js/app.js`](static/js/app.js).

---

## 4. Output

### 4.1 Server Startup Output (`python app.py`)
```text
================================================================
  CLASS RECORDS  |  THE SHIVAGROUPS OF APP
  Developed by: RUDRAKSH GARG
  Running at:   http://127.0.0.1:5050
================================================================
 * Serving Flask app 'app'
 * Debug mode: off
 * Running on http://127.0.0.1:5050
```

### 4.2 Automated Unit & API Test Output (`python -m unittest discover -s tests -v`)
```text
test_admin_only_subject_creation_and_teacher_only_attendance (test_class_records.ApiAndRbacTests.test_admin_only_subject_creation_and_teacher_only_attendance) ... ok
test_teacher_holiday_update_fees_payment_and_csv_exports (test_class_records.ApiAndRbacTests.test_teacher_holiday_update_fees_payment_and_csv_exports) ... ok
test_leave_has_less_percentage_minus_than_absent (test_class_records.CalculationTests.test_leave_has_less_percentage_minus_than_absent) ... ok
test_student_0_of_1_then_1_of_2_fifty_percent (test_class_records.CalculationTests.test_student_0_of_1_then_1_of_2_fifty_percent) ... ok
test_student_fees_left_calculation (test_class_records.CalculationTests.test_student_fees_left_calculation) ... ok
test_teacher_deduction_only_above_4_holidays (test_class_records.CalculationTests.test_teacher_deduction_only_above_4_holidays) ... ok

----------------------------------------------------------------------
Ran 6 tests in 0.297s

OK
```

---

## 5. Conclusion

The **CLASS RECORDS** project successfully fulfills the operational needs of a college department using Python, Flask, and SQLite3. It eliminates manual attendance tracking errors by dynamically updating live class ratios (`0/1` → `1/2 = 50%`), implements a fair reduced-penalty **Leave** policy, enforces strict role isolation between **Admin Panel** (subject class creation, teacher holiday deductions beyond 4 free holidays, student fee collection) and **Teacher Portal** (marking student Present, Absent, or Leave), and exports clean 1-month institutional reports. Built under **THE SHIVAGROUPS OF APP** and developed by **RUDRAKSH GARG**, the system demonstrates clean modular Python architecture, relational database persistence, automated unit verification, and a luxury responsive user interface.

@echo off
cd /d "%~dp0"
echo ========================================================
echo   CLASS RECORDS - THE SHIVAGROUPS OF APP
echo   Developed by RUDRAKSH GARG
echo ========================================================
start "" http://127.0.0.1:5050
python app.py
pause
